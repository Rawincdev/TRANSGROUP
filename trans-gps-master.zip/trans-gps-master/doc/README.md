Данный проект являеться Client-side SPA и написан с помощью AngularJS 1.6 (`https://angularjs.org`), 
в качестве UI шаблонизатора используеться Material Angular (`https://material.angularjs.org`), 
за отрисовку карт отвечает Leaflet (`http://leafletjs.com`). В роли сборщика выступает Gulp (`https://gulpjs.com`).

Исходный код лежит в директории `src/`.
- `src/app` лижит javascript код написаный на Angular
- `src/assets` - статика: картинки, стили, модифицированные javascript-библиотеки   
- `src/lua` - файлы отвечающие за генерацию данных на стороне сервера
- `src/php` - файлы которые формируют отчеты
