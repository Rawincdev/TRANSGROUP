const gulp = require('gulp');

const conf = require('../conf/gulp.conf');

gulp.task('i18n', i18n);

function i18n() {
  return gulp.src(conf.path.src('**/*.json'))
    .pipe(gulp.dest(conf.path.tmp()));
}
