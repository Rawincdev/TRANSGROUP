var fs = require('fs');
var gulp = require('gulp');
var GulpSSH = require('gulp-ssh');
var sshConfig = require('../ssh-config.json');

var gulpSSH = new GulpSSH({
    ignoreErrors: false,
    sshConfig: sshConfig
});

var destinationFolder = sshConfig.destinationFolder;

gulp.task('deploy-scripts', function () {
    return gulp
      .src(['dist/scripts/**',])
      .pipe(gulpSSH.dest(destinationFolder + 'scripts'));
});

gulp.task('deploy-styles', function () {
    return gulp
      .src(['dist/styles/**',])
      .pipe(gulpSSH.dest(destinationFolder +'styles'));
});

gulp.task('deploy-assets', function () {
  return gulp
    .src(['dist/assets/**',])
    .pipe(gulpSSH.dest(destinationFolder +'assets'));
});

gulp.task('deploy-index-file', function () {
    return gulp
      .src(['dist/index.html',])
      .pipe(gulpSSH.dest(destinationFolder));
});

gulp.task('deploy-lua', function () {
    return gulp
      .src(['dist/lua/**',])
      .pipe(gulpSSH.dest(destinationFolder + 'lua'));
});

gulp.task('deploy-lua-raw', function () {
  return gulp
    .src(['src/lua/**',])
    .pipe(gulpSSH.dest(destinationFolder + 'lua'));
});

gulp.task('deploy', gulp.series('deploy-scripts', 'deploy-lua', 'deploy-styles', 'deploy-assets', 'deploy-index-file'));