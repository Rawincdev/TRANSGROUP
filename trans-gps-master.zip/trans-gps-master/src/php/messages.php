<?php
function importMessages($lang){
    $js = file_get_contents(dirname(__FILE__) . '/../php/js/messages.'.$lang.'.js');
    $js = preg_replace("/^[^{]+/", "", $js);
    $js = preg_replace("/[^}]+$/", "", $js);
    return json_decode($js, true);
}