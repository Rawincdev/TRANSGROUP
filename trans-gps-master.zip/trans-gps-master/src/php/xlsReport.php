<?php
function isWeekend($date) {
    $chunks = explode('.', $date);
    $date = mktime(0,0,0, $chunks[1], $chunks[2], $chunks[0]);
    return (date('N', $date) >= 6);
}
//1 based
function getColumnName($index) {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $index -= 1;
    $quotient = floor($index / 26);
    if ($quotient > 0)
        return getColumnName($quotient).$chars[$index % 26];
    return $chars[$index % 26];
}

/**
 * @param DateTime $from
 * @param DateTime $to
 * @return array
 */
function formKeys($from, $to){
    $fromTimestamp = $from->getTimestamp();
    $toTimestamp = $to->getTimestamp();
    $fromTimestamp += 86400/2;
    $keys = array();
    while($fromTimestamp<=$toTimestamp){
        $date = new DateTime();
        $date->setTimestamp($fromTimestamp);
        $keys[] = array('key'=>date('Y.m.d', $fromTimestamp), 'date'=>$date);
        $fromTimestamp+=86400;
    }
    return $keys;
}

/**
 * @param PHPExcel $excel
 * @param array $data
 */
function export($excel,$data){
    global $msg;
    if(!is_array($data['rows']))
        return;
    $data['names'] = explode(';',$data['names']);
    $from = new DateTime();
    $from->setTimestamp($data['from']);
    $to = new DateTime();
    $to->setTimestamp($data['to']);

    $excel
        ->setActiveSheetIndex(0)

        ->setCellValue('B1', $msg['from'])
        ->setCellValue('C1', PHPExcel_Shared_Date::PHPToExcel($from))
        ->setCellValue('D1', $msg['to'])
        ->setCellValue('E1', PHPExcel_Shared_Date::PHPToExcel($to));
    $excel->getActiveSheet()->getStyle('C1')->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_YYYYMMDD2);
    $excel->getActiveSheet()->getStyle('E1')->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_YYYYMMDD2);

    $keys = formKeys($from, $to);
    $column = getColumnName(count($keys)+3);
    $totalColumns = array();

    // header
    $excel->getActiveSheet()->setCellValue('A3', '');
    $excel->getActiveSheet()->getStyle('A3:'.$column.'3')->applyFromArray(
    	array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
    						    'color'		=> array('argb' => 'FFc4d79b')),
              'width' => 'a'
    		 )
    	);
    for($i=0;$i<count($keys);$i++){
        $totalColumns[$keys[$i]['key']] = 0;
        $column = getColumnName($i+3);
        $excel->getActiveSheet()->getColumnDimension($column)->setAutoSize(true);
        $excel->getActiveSheet()->setCellValue($column.'3', PHPExcel_Shared_Date::PHPToExcel($keys[$i]['date']));
        $excel->getActiveSheet()->getStyle($column.'3')->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_YYYYMMDD2);
    }
    $column = getColumnName(count($keys)+3);
    $excel->getActiveSheet()->setCellValue($column.'3', $msg['total']);
    // /header

    for($c=0;$c<count($data['rows']);$c++){
        $row = $data['rows'][$c];
        $rowIndex = $c+4;
        $excel->getActiveSheet()->setCellValue('A'.$rowIndex, $row['id']);
        $excel->getActiveSheet()->setCellValue('B'.$rowIndex, $data['names'][$c]);
        $totalRow = 0;
        for($i=0;$i<count($keys);$i++){
            $column = getColumnName($i+3);
            if(isset($row['points'][$i])){//если есть по индексу - для отчета по потреблению топлива
                $val = floatval($row['points'][$i]);
            }elseif(isset($row['points'][$keys[$i]['key']])){
                $val = floatval($row['points'][$keys[$i]['key']]);
            }else{
                $val = 0;
            }
            $totalColumns[$keys[$i]['key']] += $val;
            $totalRow += $val;
            $excel->getActiveSheet()->setCellValue($column.$rowIndex, $val);
            $excel->getActiveSheet()->getStyle($column.$rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
        }
        $column = getColumnName(count($keys)+3);
        $excel->getActiveSheet()->setCellValue($column.$rowIndex, $totalRow);
        $excel->getActiveSheet()->getStyle($column.$rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
    }

    // footer
    $total = 0;
    $footerIndex = count($data['rows'])+4;
    $excel->getActiveSheet()->setCellValue('B'.$footerIndex, $msg['total']);
    for($i=0;$i<count($keys);$i++){
        $column = getColumnName($i+3);
        $val = $totalColumns[$keys[$i]['key']];
        $total += $val;
        $excel->getActiveSheet()->setCellValue($column.$footerIndex, $val);
    }
    $column = getColumnName(count($keys)+3);
    $excel->getActiveSheet()->setCellValue($column.$footerIndex, $total);
    $excel->getActiveSheet()->getStyle('A'.$footerIndex.':'.$column.$footerIndex)->applyFromArray(
    	array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
    						    'color'		=> array('argb' => 'FFc4d79b')),
              'numberformat' => array('code' => PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1)
    		 )
    	);
    // /footer
    $excel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
}