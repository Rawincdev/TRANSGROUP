<?php
function formatPeriod($seconds, $msg){
    $seconds = floatval($seconds);
    $minutes = floor($seconds/60);
   	if($minutes==0)
   		return "0".$msg['timeMinutes'];
   	if($minutes<60)
   		return $minutes.$msg['timeMinutes'];
   	if($minutes%60){
   		$mm = $minutes % 60;
   		if($mm < 10)
   			$mm = '0'.$mm;
   		return floor($minutes/60).':'.$mm.$msg['timeHours'];
   	}
   	return floor($minutes/60).$msg['timeHours'];
}

function trackLength($points){
        $d=0;
        for($i=0;$i<count($points)-1;$i++){
            $lat1 = $points[$i]['latitude'];
            $lat2 = $points[$i+1]['latitude'];
            $lon1 = $points[$i]['longitude'];
            $lon2 = $points[$i+1]['longitude'];
            $dLat = deg2rad($lat2-$lat1);
            $dLon = deg2rad($lon2-$lon1);
            $lat1 = deg2rad($lat1);
            $lat2 = deg2rad($lat2);

            $a = sin($dLat/2) * sin($dLat/2) +
                sin($dLon/2) * sin($dLon/2) * cos($lat1) * cos($lat2);
            $d += atan2(sqrt($a), sqrt(1-$a));
        }
        $d=2*6371*$d;
        return $d;
}

function getSpeedFromHistory($history){
    $maxSpeed = 0;
    for($i=1;$i<count($history);$i++){
        $distance = trackLength([$history[$i-1],$history[$i]]);
        $speed = $distance*3600 / ($history[$i]['timestamp'] - $history[$i-1]['timestamp']);
        if($speed>$maxSpeed){
            $maxSpeed = $speed;
        }
    }
    return round($maxSpeed);
}

/**
 * @param PHPExcel $excel
 * @param mixed $data
 */
function export($excel,$data){
    global $msg;
    if(!isset($data['stops']) || !is_array($data['stops']) || count($data['stops'])==0)
        return;
    if(isset($data['history'])){
        $max = getSpeedFromHistory($data['history']);
        if($max >0 && $max < intval($data['summary']['maxSpeedKmpH'])){
            $data['summary']['maxSpeedKmpH'] = $max;
        }
    }
    $hasFuel = false;
    $hasSecondFuel = false;
    $hasTFrom = false;
    $hasTTo= false;
    for($i=0;$i<count($data['stops']);$i++){
     if(isset($data['stops'][$i]['fuelTo']) && $data['stops'][$i]['fuelTo']){
       $hasFuel = true;
     }
     if(isset($data['stops'][$i]['secondFuelTo']) && $data['stops'][$i]['secondFuelTo']){
       $hasSecondFuel = true;
     }
     if(isset($data['stops'][$i]['tFrom']) && $data['stops'][$i]['tFrom']){
       $hasTFrom = true;
     }
     if(isset($data['stops'][$i]['tTo']) && $data['stops'][$i]['tTo']){
       $hasTTo = true;
     }
     if($hasFuel && $hasSecondFuel && $hasTFrom && $hasTTo){
        break;
     }
    }
    if($data['summary']['fuelSettings']){
      $hasFuel = true;
      $data['summary']['fuelSettings'] = json_decode($data['summary']['fuelSettings'], true);
    }
    $addressLetters = ['G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O'];
    $addressLetterIndex = 0;
    if ($hasFuel) {
      $addressLetterIndex += 2;
      if ($hasSecondFuel) {
        $addressLetterIndex += 1;
      }
    }
    $columnTFrom = '';
    if ($hasTFrom) {
      $addressLetterIndex += 1;
      $columnTFrom = $addressLetters[$addressLetterIndex - 1];
    }
    $columnTTo = '';
    if ($hasTTo) {
      $addressLetterIndex += 1;
      $columnTTo = $addressLetters[$addressLetterIndex - 1];
    }
    $columnAddress  = $addressLetters[$addressLetterIndex];

    $excel
        ->setActiveSheetIndex(0)

        ->setCellValue('A1', $msg['car'])
        ->setCellValue('B1', $data['deviceName'])
        ->setCellValue('A2', $msg['date'])//add date lower
        ->setCellValue('A3', $msg['distanceKm'])
        ->setCellValue('B3', $data['summary']['distanceKm'])
        ->setCellValue('A4', $msg['maxKmph'])
        ->setCellValue('B4', $data['summary']['maxSpeedKmpH'])

        ->setCellValue('A7', $msg['from'])
        ->setCellValue('B7', $msg['to'])
        ->setCellValue('C7', $msg['P'])
        ->setCellValue('D7', $msg['onWay'])
        ->setCellValue('E7', 'км.')
        ->setCellValue('F7', 'Макс км.ч.')
        ->setCellValue($columnAddress.'7', $msg['address'])
    ;
    if($hasFuel){
      $excel
            ->setActiveSheetIndex(0)
            ->setCellValue('G7', 'Fuel')
            ->setCellValue('H7', 'Расход');
      if($hasSecondFuel){
        $excel
            ->setActiveSheetIndex(0)
            ->setCellValue('H7', 'Fuel2')
            ->setCellValue('I7', 'Расход');
      }
    }
    if($hasTFrom){
      $excel
          ->setActiveSheetIndex(0)
          ->setCellValue($columnTFrom.'7', 't min');
    }
    if($hasTTo){
      $excel
      ->setActiveSheetIndex(0)
      ->setCellValue($columnTTo.'7', 't max');
    }
    if(count($data['stops'])>0){
        $date = new DateTime();
        $date->setTimestamp($data['stops'][0]['timestampFrom']);

        $excel->getActiveSheet()
            ->setCellValue('B2', PHPExcel_Shared_Date::PHPToExcel($date))
            ->getStyle('B2')->getNumberFormat()->setFormatCode('dd.mm.yyyy');
        ;
    }

    $excel->getActiveSheet()->getStyle('A7:'.$columnAddress.'7')->applyFromArray(
    	array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
    						    'color'		=> array('argb' => 'FFc4d79b')),
    		 )
    	);

    $excel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('G')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('K')->setAutoSize(true);
    $totalOnWay = 0;
    $totalOnHold = 0;
    $totalFuelUsage = 0;
    $rowIndex=7;
    $hasTk = false;
    $count = count($data['stops']);
    $last = $data['stops'][$count-1];
    $last3 = $data['stops'][$count-2];
    if($last['status'] == '5' && $last3['status'] == '3'){
      $last3['status']=2;
      $last3['timestampFrom'] = $last3['timestampTo'];
      array_splice($data['stops'], $count - 1, 0, [$last3]);
    }
    for($i=0;$i<count($data['stops']);$i++){
        $row = $data['stops'][$i];
        if($row['status'] == '3' || $row['status'] == '5'){
          continue;
        }
        $from = new DateTime();
        $from->setTimestamp($row['timestampFrom']);
        $to = new DateTime();
        $to->setTimestamp($row['timestampTo']);
        $onWay = "";
        $onHoldSeconds = 0;
        $fuel = 0;
        $distance = 0;
        $maxSpeed = 0;
        $tk = false;
        $tFrom = $row['tFrom'];
        $tTO = $row['tTo'];
        if($i>0 && $row['status']=='2' && intval($data['stops'][$i-1]['timestampFrom'])>0){
            $onWaySeconds = intval($row['timestampFrom']) - intval($data['stops'][$i-1]['timestampFrom']);
            $totalOnWay+= $onWaySeconds;
            $onWay = formatPeriod($onWaySeconds, $msg);
            if($data['stops'][$i-1]['status']=='3'){
              $distance = $data['stops'][$i-1]['distance'];
              $maxSpeed = $data['stops'][$i-1]['maxSpeed'];
              if($data['stops'][$i-1]['fuelFrom']){
                $fuel2 = 0;
                if(isset($data['stops'][$i-1]['secondFuelFrom'])){
                  $fuel2 = floatval($data['stops'][$i-1]['secondFuelFrom'])-floatval($data['stops'][$i-1]['secondFuelTo']);
                }
                $fuel = floatval($data['stops'][$i-1]['fuelFrom'])-floatval($data['stops'][$i-1]['fuelTo']);
                $totalFuelUsage += $fuel+$fuel2;
              }else if($data['summary']['fuelSettings']){
                $isSummer = $data['summary']['isSummer'];
                $isCity = floatval($data['stops'][$i-1]['distance']) < 10;
                $usage = $data['summary']['fuelSettings'][$isSummer?'summer':'winter'][$isCity?'city':'road'];
                $fuel = $usage*$data['stops'][$i-1]['distance']/100;
                $totalFuelUsage += $fuel;
                $row['fuelTo'] = 'т.к.';
                $tk = true;
                $hasTk = true;
              }
            }
        }
        if($row['status']=='2' || $row['status']=='0'){
        $onHoldSeconds = intval($row['timestampTo'])-intval($row['timestampFrom']);
        $totalOnHold += $onHoldSeconds;
        }
        $text = '';
        switch($row['status']){
            case '2':
                $text = isset($row['zone'])?$row['zone']:$row['addressYandex'];
                break;
            case '0':
                $text = $msg['powerStatus'][$row['substatus']];
                break;
            case '1':
                $text = $msg['noGPS'];
                break;
            case '4':
                $text = $msg['onIn'].' ('.$row['substatus'].')';
                break;
        }
        $rowIndex++;
        $excel
            ->getActiveSheet()
            ->setCellValue('A'.$rowIndex, PHPExcel_Shared_Date::PHPToExcel($from))
            ->setCellValue('B'.$rowIndex, PHPExcel_Shared_Date::PHPToExcel($to))
            ->setCellValue('C'.$rowIndex, formatPeriod($onHoldSeconds, $msg))
            ->setCellValue('D'.$rowIndex, $onWay)
            ->setCellValue('E'.$rowIndex, $distance)
            ->setCellValue('F'.$rowIndex, $maxSpeed)
            ->setCellValue($columnAddress.$rowIndex, $text)
        ;
        if($hasFuel){
            $excel
              ->getActiveSheet()
              ->setCellValue('G'.$rowIndex, isset($row['fuelTo'])?$row['fuelTo']:($tk?'т.к.':''))
              ->setCellValue('H'.$rowIndex, $fuel);
            if($hasSecondFuel){
              $excel
                ->getActiveSheet()
                ->setCellValue('H'.$rowIndex, isset($row['secondFuelTo'])?$row['secondFuelTo']:'')
                ->setCellValue('I'.$rowIndex, $fuel+$fuel2);
            }
        }
        if($hasTFrom){
            $excel
                ->getActiveSheet()
                ->setCellValue($columnTFrom.$rowIndex, $tFrom);
        }
        if($hasTTo){
            $excel
                ->getActiveSheet()
                ->setCellValue($columnTTo.$rowIndex, $tTO);
        }
        $excel->getActiveSheet()->getStyle('A'.$rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME4);
        $excel->getActiveSheet()->getStyle('B'.$rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME4);
        if($row['status']!='2'){
            $excel->getActiveSheet()->getStyle('A'.$rowIndex.':'.$columnAddress.$rowIndex)->applyFromArray(
            	array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            						    'color'		=> array('argb' => 'FFD9D9D9')),
            		 )
            	);
        }
    }
    $totalRowIndex = $rowIndex+1;
    $excel
        ->getActiveSheet()
        ->setCellValue('C'.$totalRowIndex, formatPeriod($totalOnHold, $msg))
        ->setCellValue('D'.$totalRowIndex, formatPeriod($totalOnWay, $msg))
        ->setCellValue('E'.$totalRowIndex, $data['summary']['distanceKm'])
        ->getStyle('A'.$totalRowIndex.':'.$columnAddress.$totalRowIndex)->applyFromArray(
        array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'FFc4d79b')),
        )
    );
    if($hasFuel){
      $excel
        ->getActiveSheet()
        ->setCellValue('A5', 'Расход'.($hasTk?'~':''))
        ->setCellValue('B5', $totalFuelUsage)
        ->setCellValue(($hasSecondFuel?'I':'H').$totalRowIndex, $totalFuelUsage)
        ->setCellValue('C5', $totalFuelUsage*100/$data['summary']['distanceKm'])
        ->getStyle('C5')->getNumberFormat()->setFormatCode('0.0');
    }

}
