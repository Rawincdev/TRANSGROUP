<?php
function isWeekend($date) {
    $chunks = explode('.', $date);
    $date = mktime(0,0,0, $chunks[1], $chunks[2], $chunks[0]);
    return (date('N', $date) >= 6);
}
/**
 * @param PHPExcel $excel
 * @param array $data
 */
function export($excel,$data){
    global $msg;
    if(!is_array($data))
        return;
    $excel
        ->setActiveSheetIndex(0)

        ->setCellValue('A1', $msg['date'])
        ->setCellValue('B1', '00:00-06:00')
        ->setCellValue('C1', '06:00-19:00')
        ->setCellValue('D1', '19:00-24:00')
        ->setCellValue('E1', '00:00-24:00')
        ->setCellValue('F1', $msg['Max']. ' '.$msg['kmph']);

    $excel->getActiveSheet()->getStyle('A1:F1')->applyFromArray(
    	array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
    						    'color'		=> array('argb' => 'FFc4d79b')),
    		 )
    	);
    $footerIndex = count($data)+2;
    $excel->getActiveSheet()->getStyle('A'.$footerIndex.':F'.$footerIndex)->applyFromArray(
    	array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
    						    'color'		=> array('argb' => 'FFc4d79b')),
    		 )
    	);
    $total =array(
        'night' => 0,
        'day' => 0,
        'evening' => 0,
        'total' => 0,
        'maxSpeed' => 0,
    );
    for($i=0;$i<count($data);$i++){
        $row = $data[$i];
        $rowIndex= $i + 2;
        $total['night']+=$row['night'];
        $total['day']+=$row['day'];
        $total['evening']+=$row['evening'];
        $total['total']+=$row['total'];
        $total['maxSpeed']= max($total['maxSpeed'],$row['maxSpeed']);
        $excel
            ->getActiveSheet()
            ->setCellValue('A'.$rowIndex, $row['date'])
            ->setCellValue('B'.$rowIndex, $row['night'])
            ->setCellValue('C'.$rowIndex, $row['day'])
            ->setCellValue('D'.$rowIndex, $row['evening'])
            ->setCellValue('E'.$rowIndex, $row['total'])
            ->setCellValue('F'.$rowIndex, $row['maxSpeed'])
        ;
        if(isWeekend($row['date'])){
            $excel->getActiveSheet()->getStyle('A'.$rowIndex)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_RED);
        }


        $excel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $excel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
        $excel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $excel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $excel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
        $excel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
    }
    $excel
        ->getActiveSheet()
        ->setCellValue('A'.$footerIndex, $msg['total'])
        ->setCellValue('B'.$footerIndex, $total['night'])
        ->setCellValue('C'.$footerIndex, $total['day'])
        ->setCellValue('D'.$footerIndex, $total['evening'])
        ->setCellValue('E'.$footerIndex, $total['total'])
        ->setCellValue('F'.$footerIndex, $total['maxSpeed'])
    ;
}