<?php
function formatPeriod($seconds, $msg){
    $seconds = floatval($seconds);
    $minutes = floor($seconds/60);
   	if($minutes==0)
   		return "0".$msg['timeMinutes'];
   	if($minutes<60)
   		return $minutes.$msg['timeMinutes'];
   	if($minutes%60){
   		$mm = $minutes % 60;
   		if($mm < 10)
   			$mm = '0'.$mm;
   		return floor($minutes/60).':'.$mm.$msg['timeHours'];
   	}
   	return floor($minutes/60).$msg['timeHours'];
}

function trackLength($points){
        $d=0;
        for($i=0;$i<count($points)-1;$i++){
            $lat1 = $points[$i]['latitude'];
            $lat2 = $points[$i+1]['latitude'];
            $lon1 = $points[$i]['longitude'];
            $lon2 = $points[$i+1]['longitude'];
            $dLat = deg2rad($lat2-$lat1);
            $dLon = deg2rad($lon2-$lon1);
            $lat1 = deg2rad($lat1);
            $lat2 = deg2rad($lat2);

            $a = sin($dLat/2) * sin($dLat/2) +
                sin($dLon/2) * sin($dLon/2) * cos($lat1) * cos($lat2);
            $d += atan2(sqrt($a), sqrt(1-$a));
        }
        $d=2*6371*$d;
        return $d;
}

function getSpeedFromHistory($history){
    $maxSpeed = 0;
    for($i=1;$i<count($history);$i++){
        $distance = trackLength([$history[$i-1],$history[$i]]);
        $speed = $distance*3600 / ($history[$i]['timestamp'] - $history[$i-1]['timestamp']);
        if($speed>$maxSpeed){
            $maxSpeed = $speed;
        }
    }
    return round($maxSpeed);
}

/**
 * @param PHPExcel $excel
 * @param mixed $data
 */
function export($excel,$data){
    global $msg;
    if(!isset($data['stops']) || !is_array($data['stops']) || count($data['stops'])==0)
        return;
    if(isset($data['history'])){
        $max = getSpeedFromHistory($data['history']);
        if($max >0 && $max < intval($data['summary']['maxSpeedKmpH'])){
            $data['summary']['maxSpeedKmpH'] = $max;
        }
    }
    $excel
        ->setActiveSheetIndex(0)

        ->setCellValue('A1', $msg['car'])
        ->setCellValue('C1', $data['deviceName'])
        ->setCellValue('A2', $msg['date'])//add date lower
        ->setCellValue('A3', $msg['distanceKm'])
        ->setCellValue('C3', $data['summary']['distanceKm'])
        ->setCellValue('A4', $msg['maxKmph'])
        ->setCellValue('C4', $data['summary']['maxSpeedKmpH'])

        ->setCellValue('A6', $msg['date'])
        ->setCellValue('B6', $msg['from'])
        ->setCellValue('C6', $msg['to'])
        ->setCellValue('D6', $msg['P'])
        ->setCellValue('E6', $msg['onWay'])
        ->setCellValue('F6', $msg['address'])
    ;

    if(count($data['stops'])>0){
        $date = new DateTime();
        $date->setTimestamp($data['stops'][0]['timestampFrom']);

        $excel->getActiveSheet()
            ->setCellValue('C2', PHPExcel_Shared_Date::PHPToExcel($date))
            ->getStyle('C2')->getNumberFormat()->setFormatCode('dd.mm.yyyy');
        ;
    }

    $excel->getActiveSheet()->getStyle('A6:F6')->applyFromArray(
    	array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
    						    'color'		=> array('argb' => 'FFc4d79b')),
    		 )
    	);

    $excel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
    $totalOnWay = 0;
    $totalOnHold = 0;
    for($i=0;$i<count($data['stops']);$i++){
        $row = $data['stops'][$i];
        $rowIndex= $i + 7;
        $from = new DateTime();
        $from->setTimestamp($row['timestampFrom']);
        $to = new DateTime();
        $to->setTimestamp($row['timestampTo']);
        $onWay = "";
        if($i>0 && $row['status']=='2' && intval($data['stops'][$i-1]['timestampTo'])>0){
            $onWaySeconds = intval($row['timestampFrom']) - intval($data['stops'][$i-1]['timestampTo']);
            $totalOnWay+= $onWaySeconds;
            $onWay = formatPeriod($onWaySeconds, $msg);
        }
        if($row['status']=='2' || $row['status']=='0'){
        $onHoldSeconds = intval($row['timestampTo'])-intval($row['timestampFrom']);
        $totalOnHold += $onHoldSeconds;
        }
        $text = '';
        switch($row['status']){
            case '2': $text = isset($row['zone'])?$row['zone']:$row['addressYandex'];break;
            case '0':
                $text = $msg['powerStatus'][$row['substatus']];
                break;
            case '1':
                $text = $msg['noGPS'];
                break;
            case '4':
                $text = $msg['onIn'].' ('.$row['substatus'].')';
                break;
        }

        $excel
            ->getActiveSheet()
            ->setCellValue('A'.$rowIndex, PHPExcel_Shared_Date::PHPToExcel($from))
            ->setCellValue('B'.$rowIndex, PHPExcel_Shared_Date::PHPToExcel($from))
            ->setCellValue('C'.$rowIndex, PHPExcel_Shared_Date::PHPToExcel($to))
            ->setCellValue('D'.$rowIndex, formatPeriod($onHoldSeconds, $msg))
            ->setCellValue('E'.$rowIndex, $onWay)
            ->setCellValue('F'.$rowIndex, $text)
        ;
        $excel->getActiveSheet()->getStyle('A'.$rowIndex)->getNumberFormat()->setFormatCode('dd.mm.yyyy');
        $excel->getActiveSheet()->getStyle('B'.$rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME4);
        $excel->getActiveSheet()->getStyle('C'.$rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME4);
        if($row['status']!='2'){
            $excel->getActiveSheet()->getStyle('A'.$rowIndex.':F'.$rowIndex)->applyFromArray(
            	array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            						    'color'		=> array('argb' => 'FFD9D9D9')),
            		 )
            	);
        }
    }
    $totalRowIndex = count($data['stops'])+7;
    $excel
        ->getActiveSheet()
        ->setCellValue('A'.$totalRowIndex, formatPeriod($totalOnHold, $msg))
        ->setCellValue('D'.$totalRowIndex, formatPeriod($totalOnWay, $msg))
        ->getStyle('A'.$totalRowIndex.':E'.$totalRowIndex)->applyFromArray(
        array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'FFc4d79b')),
        )
    );
    ;

}