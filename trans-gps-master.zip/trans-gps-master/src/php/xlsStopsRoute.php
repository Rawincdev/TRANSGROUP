<?php
function formatPeriod($seconds, $msg){
    $seconds = floatval($seconds);
    $minutes = floor($seconds/60);
   	if($minutes==0)
   		return "0".$msg['timeMinutes'];
   	if($minutes<60)
   		return $minutes.$msg['timeMinutes'];
   	if($minutes%60){
   		$mm = $minutes % 60;
   		if($mm < 10)
   			$mm = '0'.$mm;
   		return floor($minutes/60).':'.$mm.$msg['timeHours'];
   	}
   	return floor($minutes/60).$msg['timeHours'];
}

function trackLength($points){
        $d=0;
        for($i=0;$i<count($points)-1;$i++){
            $lat1 = $points[$i]['latitude'];
            $lat2 = $points[$i+1]['latitude'];
            $lon1 = $points[$i]['longitude'];
            $lon2 = $points[$i+1]['longitude'];
            $dLat = deg2rad($lat2-$lat1);
            $dLon = deg2rad($lon2-$lon1);
            $lat1 = deg2rad($lat1);
            $lat2 = deg2rad($lat2);

            $a = sin($dLat/2) * sin($dLat/2) +
                sin($dLon/2) * sin($dLon/2) * cos($lat1) * cos($lat2);
            $d += atan2(sqrt($a), sqrt(1-$a));
        }
        $d=2*6371*$d;
        return $d;
}

function getSpeedFromHistory($history){
    $maxSpeed = 0;
    for($i=1;$i<count($history);$i++){
        $distance = trackLength([$history[$i-1],$history[$i]]);
        $speed = $distance*3600 / ($history[$i]['timestamp'] - $history[$i-1]['timestamp']);
        if($speed>$maxSpeed){
            $maxSpeed = $speed;
        }
    }
    return round($maxSpeed);
}

/**
 * @param PHPExcel $excel
 * @param mixed $data
 */
function export($excel,$data){
    global $msg;
    if(!isset($data['stops']) || !is_array($data['stops']) || count($data['stops'])==0)
        return;
    if(isset($data['history'])){
        $max = getSpeedFromHistory($data['history']);
        if($max >0 && $max < intval($data['summary']['maxSpeedKmpH'])){
            $data['summary']['maxSpeedKmpH'] = $max;
        }
    }
    $hasFuel = false;
    $hasSecondFuel = false;
    for($i=0;$i<count($data['stops']);$i++){
     if(isset($data['stops'][$i]['fuelTo']) && $data['stops'][$i]['fuelTo']){
       $hasFuel = true;
     }
     if(isset($data['stops'][$i]['secondFuelTo']) && $data['stops'][$i]['secondFuelTo']){
       $hasSecondFuel = true;
     }
     if($hasFuel && $hasSecondFuel){
        break;
     }
    }
    if($data['summary']['fuelSettings']){
      $hasFuel = true;
      $data['summary']['fuelSettings'] = json_decode($data['summary']['fuelSettings'], true);
    }
    $columnAddress  = $hasFuel?'J':'H';
    if($hasSecondFuel){
      $columnAddress = 'K';
    }
    $excel
        ->setActiveSheetIndex(0)

        ->setCellValue('A1', $msg['car'])
        ->setCellValue('B1', $data['deviceName'])
        ->setCellValue('A2', $msg['date'])//add date lower
        ->setCellValue('A3', $msg['distanceKm'])
        ->setCellValue('B3', $data['summary']['distanceKm'])
        ->setCellValue('A4', $msg['maxKmph'])
        ->setCellValue('B4', $data['summary']['maxSpeedKmpH'])

        ->setCellValue('A7', $msg['date'])
        ->setCellValue('B7', $msg['from'])
        ->setCellValue('C7', $msg['to'])
        ->setCellValue('D7', $msg['P'])
        ->setCellValue('E7', $msg['onWay'])
        ->setCellValue('F7', 'км.')
        ->setCellValue('G7', 'Макс км.ч.')
        ->setCellValue($columnAddress.'7', $msg['address'])
    ;
    if($hasFuel){
     $excel
            ->setActiveSheetIndex(0)
            ->setCellValue('H7', 'Fuel')
            ->setCellValue('I7', 'Расход');
      if($hasSecondFuel){
        $excel
            ->setActiveSheetIndex(0)
            ->setCellValue('I7', 'Fuel2')
            ->setCellValue('J7', 'Расход');
      }
    }
    $dateFrom = new DateTime();
    $dateFrom->setTimestamp($data['stops'][0]['timestampFrom']);
    $dateTo = new DateTime();

    $excel->getActiveSheet()->getStyle('A7:'.$columnAddress.'7')->applyFromArray(
    	array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
    						    'color'		=> array('argb' => 'FFc4d79b')),
    		 )
    	);

    $excel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('G')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);
    $excel->getActiveSheet()->getColumnDimension('K')->setAutoSize(true);
    $totalOnWay = 0;
    $totalOnHold = 0;
    $totalFuelUsage = 0;
    $rowIndex=7;
    $hasTk = false;
    $count = count($data['stops']);
    $last = $data['stops'][$count-1];
    $last3 = $data['stops'][$count-2];
    if($last['status'] == '5' && $last3['status'] == '3'){
      $last3['status']=2;
      $last3['timestampFrom'] = $last3['timestampTo'];
      array_splice($data['stops'], $count - 1, 0, [$last3]);
    }
    for($i=0;$i<count($data['stops']);$i++){
        $row = $data['stops'][$i];
        if($row['status'] == '3' || $row['status'] == '5'){
          continue;
        }
        $from = new DateTime();
        $from->setTimestamp($row['timestampFrom']);
        $to = new DateTime();
        $to->setTimestamp($row['timestampTo']);
        $dateTo = $to;
        $onWay = "";
        $onHoldSeconds = 0;
        $fuel = 0;
        $distance = 0;
        $maxSpeed = 0;
        $tk = false;
        $text = '';
        if($i>0 && $row['status']=='2' && intval($data['stops'][$i-1]['timestampFrom'])>0){
            $onWaySeconds = intval($row['timestampFrom']) - intval($data['stops'][$i-1]['timestampFrom']);
            $totalOnWay+= $onWaySeconds;
            $onWay = formatPeriod($onWaySeconds, $msg);
            if($data['stops'][$i-1]['status']=='3'){
              $distance = $data['stops'][$i-1]['distance'];
              $maxSpeed = $data['stops'][$i-1]['maxSpeed'];
              if($row['fuelFrom'] < $row['fuelTo']){
                $second = '';
                if(isset($row['secondFuelFrom'])){
                  $second = ' + '.($row['secondFuelTo']-$row['secondFuelFrom']).'л ('.$row.secondFuelFrom .'>>'.$row['secondFuelTo'].')</span> ';
                }
                $prefix = 'Заправка: '.($row['fuelTo']-$row['fuelFrom']).'л ('.$row.fuelFrom .'>>'.$row['fuelTo'].')'.$second.'</span> ';
              }else
              if($row['fuelFrom'] > $row.fuelTo){
                $second = '';
                if(isset($row['secondFuelFrom'])){
                  $second = ' + '.($row['secondFuelFrom']-$row['secondFuelTo']).'л ('.$row.secondFuelFrom .'>>'.$row['secondFuelTo'].')</span> ';
                }
                $prefix = '<span class="fuel-change">Слив: '.($row.fuelFrom-$row.fuelTo).'л ('.$row['fuelFrom'] .'>>'.$row.fuelTo.')'.$second.'</span> ';
              }else if($row['fuelFrom']){
                $second = '';
                if(isset($row['secondFuelFrom'])){
                  $second = ' + '.$row['secondFuelFrom'];
                }
                $prefix = $row['fuelFrom'].'л'.$second;
              }
              if($data['stops'][$i-1]['fuelFrom']){
                $fuel2 = 0;
                if(isset($data['stops'][$i-1]['secondFuelFrom'])){
                  $fuel2 = floatval($data['stops'][$i-1]['secondFuelFrom'])-floatval($data['stops'][$i-1]['secondFuelTo']);
                }
                $fuel = floatval($data['stops'][$i-1]['fuelFrom'])-floatval($data['stops'][$i-1]['fuelTo']);
                $totalFuelUsage += $fuel+$fuel2;
              }else if($data['summary']['fuelSettings']){
                $isSummer = $data['summary']['isSummer'];
                $isCity = floatval($data['stops'][$i-1]['distance']) < 10;
                $usage = $data['summary']['fuelSettings'][$isSummer?'summer':'winter'][$isCity?'city':'road'];
                $fuel = $usage*$data['stops'][$i-1]['distance']/100;
                $totalFuelUsage += $fuel;
                $row['fuelTo'] = 'т.к.';
                $tk = true;
                $hasTk = true;
              }
            }
        }
        if($row['status']=='2' || $row['status']=='0'){
        $onHoldSeconds = intval($row['timestampTo'])-intval($row['timestampFrom']);
        $totalOnHold += $onHoldSeconds;
        }
        switch($row['status']){
            case '2':
                $text .= isset($row['zone'])?$row['zone']:$row['addressYandex'];
                break;
            case '0':
                $text .= $msg['powerStatus'][$row['substatus']];
                break;
            case '1':
                $text .= $msg['noGPS'];
                break;
            case '4':
                $text .= $msg['onIn'].' ('.$row['substatus'].')';
                break;
        }
        $rowIndex++;
        $excel
            ->getActiveSheet()
            ->setCellValue('A'.$rowIndex, PHPExcel_Shared_Date::PHPToExcel($from))
            ->setCellValue('B'.$rowIndex, PHPExcel_Shared_Date::PHPToExcel($from))
            ->setCellValue('C'.$rowIndex, PHPExcel_Shared_Date::PHPToExcel($to))
            ->setCellValue('D'.$rowIndex, formatPeriod($onHoldSeconds, $msg))
            ->setCellValue('E'.$rowIndex, $onWay)
            ->setCellValue('F'.$rowIndex, $distance)
            ->setCellValue('G'.$rowIndex, $maxSpeed)
            ->setCellValue($columnAddress.$rowIndex, $text)
        ;
        if($hasFuel){
            $excel
              ->getActiveSheet()
              ->setCellValue('H'.$rowIndex, isset($row['fuelTo'])?$row['fuelTo']:($tk?'т.к.':''))
              ->setCellValue('I'.$rowIndex, $fuel);
            if($hasSecondFuel){
              $excel
                ->getActiveSheet()
                ->setCellValue('I'.$rowIndex, isset($row['secondFuelTo'])?$row['secondFuelTo']:'')
                ->setCellValue('J'.$rowIndex, $fuel+$fuel2);
            }
        }
        $excel->getActiveSheet()->getStyle('A'.$rowIndex)->getNumberFormat()->setFormatCode('dd.mm.yyyy');
        $excel->getActiveSheet()->getStyle('B'.$rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME4);
        $excel->getActiveSheet()->getStyle('C'.$rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME4);
        if($row['status']!='2'){
            $excel->getActiveSheet()->getStyle('A'.$rowIndex.':'.$columnAddress.$rowIndex)->applyFromArray(
            	array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            						    'color'		=> array('argb' => 'FFD9D9D9')),
            		 )
            	);
        }
    }

    if(count($data['stops'])>0){
        $excel->getActiveSheet()
            ->setCellValue('B2', PHPExcel_Shared_Date::PHPToExcel($dateFrom))
            ->setCellValue('C2', PHPExcel_Shared_Date::PHPToExcel($dateTo));
        $excel->getActiveSheet()->getStyle('B2')->getNumberFormat()->setFormatCode('dd.mm.yyyy');
        $excel->getActiveSheet()->getStyle('C2')->getNumberFormat()->setFormatCode('dd.mm.yyyy');
    }

    $totalRowIndex = $rowIndex+1;
    $excel
        ->getActiveSheet()
        ->setCellValue('D'.$totalRowIndex, formatPeriod($totalOnHold, $msg))
        ->setCellValue('E'.$totalRowIndex, formatPeriod($totalOnWay, $msg))
        ->setCellValue('F'.$totalRowIndex, $data['summary']['distanceKm'])
        ->getStyle('A'.$totalRowIndex.':'.$columnAddress.$totalRowIndex)->applyFromArray(
        array('fill' => array( 'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
            'color'		=> array('argb' => 'FFc4d79b')),
        )
    );
    if($hasFuel){
          $excel
            ->getActiveSheet()
            ->setCellValue('A5', 'Расход'.($hasTk?'~':''))
            ->setCellValue('B5', $totalFuelUsage)
            ->setCellValue(($hasSecondFuel?'J':'I').$totalRowIndex, $totalFuelUsage)
            ->setCellValue('C5', $totalFuelUsage*100/$data['summary']['distanceKm'])
            ->getStyle('C5')->getNumberFormat()->setFormatCode('0.0');
    }

}