<?php
date_default_timezone_set('Europe/Kiev');
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';
$excel = new PHPExcel();
$data = file_get_contents("php://input");
if($_REQUEST['cp1251']=='true')
    $data = iconv("cp1251","utf-8",$data);
$data = json_decode($data,true);
$fileName = 'export.xls';
require_once dirname(__FILE__) . '/messages.php';
$msg = importMessages($data['lang']);
switch($data['type']){
    case 'stops':
        $dateFrom = new DateTime();
        $dateFrom->setTimestamp($data['tsFrom']);
        $dateTo = new DateTime();
        $dateTo->setTimestamp($data['tsTo']);

        if($data['subtype'] == 'route'){
          require_once dirname(__FILE__) . '/xlsStopsRoute.php';
          $fileName = $data['deviceName'].'_route_'.$dateFrom->format('d-m-Y').'_'.$dateTo->format('d-m-Y').'.xls';//Название_машины(или ID)_route(stops)_дата_начала_дата конца.xls
        }else{
          require_once dirname(__FILE__) . '/xlsStops.php';
          $fileName = $data['deviceName'].'_stops_'.$dateFrom->format('d-m-Y').'.xls';//Название_машины(или ID)_route(stops)_дата_начала_дата конца.xls
        }
        export($excel, $data);
        break;
    case 'distance':
        $dateFrom = new DateTime();
        $dateFrom->setTimestamp($data['tsFrom']);
        $dateTo = new DateTime();
        $dateTo->setTimestamp($data['tsTo']);

        require_once dirname(__FILE__) . '/xlsDistance.php';
        export($excel, $data['rows']);
        $fileName = $data['deviceName'].'_distance_'.$dateFrom->format('d-m-Y').'_'.$dateTo->format('d-m-Y').'.xls';//Название_машины(или ID)_route(stops)_дата_начала_дата конца.xls
        break;
    case 'report':
        require_once dirname(__FILE__) . '/xlsReport.php';
        export($excel, $data);
        $fileName = 'report.xls';
        break;
    case 'fuel':
        $dateFrom = new DateTime();
        $dateFrom->setTimestamp($data['tsFrom']);
        $dateTo = new DateTime();
        $dateTo->setTimestamp($data['tsTo']);

        require_once dirname(__FILE__) . '/xlsFuel.php';
        $fileName = $data['deviceName'].'_fuel_'.$dateFrom->format('d-m-Y').'_'.$dateTo->format('d-m-Y').'.xls';
        export($excel, $data);
        break;
}

// Redirect output to a client's web browser (Excel5)
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="'.$fileName.'"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($excel, 'Excel5');
$objWriter->save('php://output');
