local router = {}
local utils = require(ngx.var.lua_mod_prefix.."utils")
local store = require(ngx.var.lua_mod_prefix.."store")

function Set (list)
    local set = {}
    for _, l in ipairs(list) do set[l] = true end
    return set
end

function processDistance(chunks, lang)
    local data = { type = "distance",
            lang = lang,
        rows = {}};
    for _,row in pairs(chunks) do
        if row~="" then
            local parts = utils.gsplit(row, ";");
            local tmp = utils.stripTags(parts[1]);
            if tmp ~= 'Total' then
                data.rows[#data.rows+1] = {
                    date = tmp,
                    night = parts[2],
                    day = parts[3],
                    evening = parts[4],
                    total = parts[5],
                    maxSpeed = parts[6],
                    timestamp = utils.date_to_timestamp(tmp)
                }
                --ngx.log(ngx.ERR, "login caugth:",utils.date_to_timestamp(tmp))
            end
        end
    end
    return data
end

function processStops(chunks, lang, history)
    local data = {
        type = "stops",
        lang = lang,
        history = history,
        stops = {},
        summary = {}
    }
    if #chunks>2 then
        for _,row in pairs(chunks) do
            if row~="" then
                ngx.log(ngx.ERR, row);
                local parts = utils.gsplit(row, ";");
                local stop = {
                                timestampFrom = parts[2],
                                timestampTo = parts[3],
                                status = parts[1]
                            };
                if stop.status == '5' then
                    data.summary.distanceKm = parts[4]/10
                    data.summary.maxSpeedKmpH = parts[5];
                    data.summary.engine = parts[6];
                end
                if stop.status == '2'then
                    stop.latitude = parts[4]/600000;
                    stop.longitude = parts[5]/600000;
                    stop.engine = parts[6];
                    stop.addressGoogle = parts[11];
                    stop.addressYandex = parts[12];
                else
                    if stop.status == '3'then
                        stop.distance = parts[4]/10;
                        stop.maxSpeed = parts[5];
                    else
                        if stop.status == '0' then
                            stop.substatus = parts[4]
                        end
                    end
                end
                stop.tFrom = parts[7];
                stop.tTo = parts[8];
                stop.fuelFrom = parts[9];
                stop.fuelTo = parts[10];
                if parts[13] then
                    stop.secondFuelFrom = parts[13];
                    stop.secondFuelTo = parts[14];
                end
                data.stops[#data.stops + 1] = stop
            end
        end
    end
    return data
end

function get_history_points(chunks)
    local data = {}
    for _,row in pairs(chunks) do
        if row~="" then
            local parts = utils.gsplit(row, ";")
            data[#data+1] = {
                latitude = parts[4]/600000,
                longitude = parts[5]/600000,
                speed = tonumber(parts[6]),
                timestamp = parts[2]
            }
        end
    end
    return data;
end

function add_geozones_to_stops(data, cp1251)
    if store.has_permission("geo-zones") then
        local iconv = require(ngx.var.lua_mod_prefix .. "iconv")
        for i = 1, #data.stops do
            if data.stops[i].status == '2' then
                local name = store.get_point_name(data.stops[i].latitude, data.stops[i].longitude)
--                if cp1251 and name ~= ngx.null then
                    --		if cp1251 and name~=false then
--                    data.stops[i].zone = iconv.Utf8ToAnsi(tostring(name))
--                end
                if name ~= ngx.null then
                    if cp1251 then
                        data.stops[i].zone = iconv.Utf8ToAnsi(tostring(name))
                    else
                        data.stops[i].zone = tostring(name)
                    end
                end
            end
        end
    end
    return data
end

function form_report_distance(from, to, id_list)
    local ids = utils.gsplit(id_list, ",")
    local from = from
    local to = to
    local url_suffix = '&x='..from..'&y='..to
    local from = 1;
    local data = {}
    local header;
    ngx.log(ngx.ERR, "distance requests count: ",#ids)
    while from <= #ids do
        ngx.log(ngx.ERR, "distance requests from: ", from)
        local requests = {}
        for i=from,math.min(from+49,#ids) do
            requests[i-from+1] = {"/x.x", {method = ngx.HTTP_POST, body ="c=5&i="..ids[i]..url_suffix} }
        end
        local resps = { ngx.location.capture_multi(requests) }
        ngx.log(ngx.ERR, "distance requests done: ", #resps)
        for i=1,#resps do
            local resp = resps[i]
            local id = ids[i+from-1]
            local chunks = utils.gsplit(resp.body)
            local item = {}
            for k=3,#chunks do
                local parts = utils.gsplit(chunks[k], ";");
                local tmp = utils.stripTags(parts[1]);
                if tmp ~= 'Total' and tmp ~= "" then
                    item[tmp] = parts[5]
                end
            end
            data[#data+1] = {id = id, points = item}
        end
        from = from + 50;
        header = resps[1].header
    end
    utils.forward_headers(header)
    return data
end

function form_report_fuel_usage(from, to, id_list, limits)
    local ids = utils.gsplit(id_list, ",")
    local times = utils.gsplit(limits, ";")
    local usage = store.get_bulk_fuel_usage(ids);
    local url_suffix = '&x='..from..'&y='..to
    local seasons = prepare_seasons(store.get_setting('seasons'));
    local data = {}
    local ids_num = math.min(50, #ids)--не строим для более 50 машин
    for i=1,ids_num do
        data[i] = {id=ids[i], points = {}}
    end
    local header;
    -- за каждый день
    for day_index=1, #times-1 do
        local from = 1
        -- для каждого авто
        while from <= ids_num do
            local requests = {}
            for i=from,math.min(from+99,ids_num) do
                requests[i-from+1] = {"/x.x", {method = ngx.HTTP_POST, body ="c=4&i="..ids[i]
                        .."&x="..times[day_index].."&y="..(tonumber(times[day_index+1])-1)} }
            end
            local resps = { ngx.location.capture_multi(requests) }
            for i=1,#resps do
                if usage[ids[i+from-1]] then -- для авто указано потребление
                    data[i+from-1].points[day_index] = get_fuel_usage_by_history_response(resps[i],
                        usage[ids[i+from-1]], is_summer(times[day_index], seasons))
                end
            end
            from = from + 100;
            header = resps[1].header
        end
    end
    utils.forward_headers(header)
    return data
end

function form_report(from, to, id_list, report_name, limits)
    if report_name == 'distance' then
        return form_report_distance(from, to, id_list)
    elseif report_name == 'fuel-usage' and store.has_permission("fuel-calc") then
        return form_report_fuel_usage(from, to, id_list, limits)
    end
end

function form_report_schedule(from, to, id_list, schedule, lang)
    from = tonumber(from)
    to = tonumber(to)
    local header
    local ids = utils.gsplit(id_list, ",")
    if schedule ~= "0" then
        -- remove other assignments
    end
    local result = {}
    local unvisited = {}
    while from < to do
        for _, v in pairs(ids) do
            local id = {}
            id[1] = v
            local assigned = store.get_assigned_schedules(from, from, id)
            local res = ngx.location.capture('/x.x', {method = ngx.HTTP_POST,
                body = "l="..lang.."&c=28&i="..v.."&x="..from.."&y="..to})
            header = res.header
            local chunks = utils.gsplit(res.body)
            table.remove(chunks, 1)
            table.remove(chunks, 1)
            local data = processStops(chunks, lang, nil)
            data = add_geozones_to_stops(data, true)
            local iconv = require(ngx.var.lua_mod_prefix.."iconv")
            if #assigned > 0 then --назначем МЛ на ТС на день
                local schedule = store.get_schedule_by_id(assigned[1].scheduleId)
                local zones = store.get_zones_by_schedule_id(assigned[1].scheduleId)
                local zone_names = {}
                for _, zone in pairs(zones) do
                    zone_names[iconv.Utf8ToAnsi(tostring(zone.name))] = 1
                end
                for _, stop in pairs(data.stops) do
                    stop.carId = v
                    stop.schedule = iconv.Utf8ToAnsi(schedule.name)
                    result[#result+1] = stop
                    if stop.zone ~= nil then
                        zone_names[stop.zone] = nil
                    end
                end
                for zone_name, visited in pairs(zone_names) do
                    if visited ~=nil then
                        if unvisited[zone_name] ==  nil then
                            unvisited[zone_name] = {}
                        end
                        unvisited[zone_name][#unvisited[zone_name]+1] = v
                    end
                end
            else
                for _, stop in pairs(data.stops) do
                    stop.carId = v
                    result[#result+1] = stop
                end
            end
        end
        from = from+86400
    end
    utils.forward_headers(header)
    return {
        items = result,
        unvisited = unvisited
    }
    -- get schedule ids (if schedule ==0)
    -- get geo zones for ids
    -- get stops for id list in date range
    -- replace stops with geozones (per car)
    -- keep list of unvisited geo zones (list of cars per zone)
end

function parse_ussd_responses(lines)
    local data = {}
    local timestampLength = 10
    for _,v in pairs(lines) do
        if v ~= "" then
            local ussdCommand = utils.gsplit(v:sub(timestampLength+2,30),' ')[1]
            local answerStartPosition = timestampLength + 3 + ussdCommand:len()
            local len = v:len()
            if v:sub(-4)=='",64' then
                len = len - 4
            end
            if v:sub(answerStartPosition,3) == '0,"' then
                answerStartPosition = answerStartPosition + 3;
            end
            local response = v:sub(answerStartPosition, len - answerStartPosition)
            data[#data+1] = {
                timestamp = tonumber(v:sub(1, timestampLength)),
                request = ussdCommand,
                response = response
            }
        end
    end
    return data
end

function calculate_ussd_summary(ussds)
    local balances = Set { "*111#", "*100#", "*101#" }
    local summary = {}
    local i
    if #ussds > 0 then
        local nextDate = 0
        local lastBalance = -1;
        for i = #ussds, 1, -1 do
            local item = ussds[i]
            if balances[item.request] and item.timestamp >= nextDate then
                local match = item.response:match("%d+[%.,]%d%d")
                if match~=nil then
                    match = match:gsub(",",".")
                    lastBalance = tonumber(match)
                    if #summary < 3 then
                        summary[#summary+1] = lastBalance
                        if #summary < 3 then
                            -- я знаю, что писать лесенкой некрасиво, но...
                            nextDate = item.timestamp - 864000
                        end
                    end
                end
            end
        end
        while #summary < 3 do
            summary[#summary+1] = -1
        end
        summary[#summary+1] = lastBalance
    end
    return summary
end

function parse_account_settings(line)
    local parts = utils.gsplit(line, ';')
    if #parts < 7 then
        return nil
    end
    return {
        id = parts[1],
        simPassword = parts[2],
        simNumber = parts[4],
        softwareVersion = parts[7],
        outputs = parts[8],
        name = parts[9],
        maxSpeed = parts[10],
        gpsPeriod = parts[11]
    };
end

function get_account_card_balance(id_list)
    local data = {}
    local ids = utils.gsplit(id_list, ",")
    local from = 1;
    while from <= #ids do
        local requests = {}
        for i=from,math.min(from+99,#ids) do
            requests[i-from+1] = {"/x.x", {method = ngx.HTTP_POST, body ="c=9&i="..ids[i]} }
        end
        local resps = { ngx.location.capture_multi(requests) }
        for i=1,#resps do
            local resp = resps[i]
            local id = ids[i+from-1]
            local chunks = utils.gsplit(resp.body)
            local ussds = parse_ussd_responses(chunks)
            data[#data+1] = {id = id, summary = calculate_ussd_summary(ussds)}
        end
        from = from + 100;
    end
    from = 1;
    while from <= #ids do
        local requests = {}
        for i=from,math.min(from+99,#ids) do
            requests[i-from+1] = {"/x.x", {method = ngx.HTTP_POST, body ="c=7&i="..ids[i]} }
        end
        local resps = { ngx.location.capture_multi(requests) }
        for i=1,#resps do
            local resp = resps[i]
            local chunks = utils.gsplit(resp.body)
            local sett = parse_account_settings(chunks[4])
            if sett ~= nil then
                data[i+from-1]["simNumber"] = sett["simNumber"]
                data[i+from-1]["name"] = sett["name"]
            end
        end
        from = from + 100;
    end
    return data
end

function get_distance_scaled(p1, p2)
    local dLat = math.rad(p2.latitude-p1.latitude);
    local dLon = math.rad(p2.longitude-p1.longitude);
    local lat1 = math.rad(p1.latitude);
    local lat2 = math.rad(p2.latitude);

    local a = math.sin(dLat/2) * math.sin(dLat/2) +
              math.sin(dLon/2) * math.sin(dLon/2) *
              math.cos(lat1) * math.cos(lat2);
    return math.atan2(math.sqrt(a), math.sqrt(1-a));--need to 2*6371*
end

function get_fuel_usage_by_track(track, usage)
    local road_distance = 0;
    local city_distance = 0;
    for i=2,#track do
        local distance = get_distance_scaled(track[i-1], track[i])
        if track[i].speed > 50 and math.abs(track[i].speed - track[i-1].speed)<=5 then
            road_distance = road_distance + distance
        else
            city_distance = city_distance + distance
        end
    end
    return 2*6371*(usage.road*road_distance + usage.city*city_distance)/100
end

function is_date_table_less_then(t1, t2)
    return t1.month < t2.month or
            (t1.month == t2.month and t1.day < t2.day);
end

function is_summer(date, seasons)
    -- (date > summer and (date<winter or winter<summer)) or --05 (08) 10, 05 (08) 02
    -- (date < winter and winter<summer) -- (01) 06 03
    local parsed = os.date("*t", date)
    local dlts = is_date_table_less_then(parsed, seasons.summer);
    local dltw = is_date_table_less_then(parsed, seasons.winter);
    return (not dlts and (dltw or seasons.wlts)) or (dltw and seasons.wlts)
end

function prepare_seasons(seasons)
    local prepared = {}
    if seasons == "" then
        seasons = {summer='2000.04.15', winter='2000.10.15' }
    end
    local chunks = utils.gsplit(seasons.summer, '%.');
    prepared.summer = {
        month = tonumber(chunks[2]),
        day = tonumber(chunks[3])
    }
    chunks = utils.gsplit(seasons.winter, '%.');
    prepared.winter = {
        month = tonumber(chunks[2]),
        day = tonumber(chunks[3])
    }
    -- winter less then summer
    prepared.wlts = is_date_table_less_then(prepared.winter, prepared.summer)
    return prepared
end

function get_fuel_usage_by_history_response(response, usage, summer)
    local chunks = utils.gsplit(response.body)
    table.remove(chunks, 1)
    table.remove(chunks, 1)
    table.remove(chunks, 1)
    local points = get_history_points(chunks)
    if summer then
        return get_fuel_usage_by_track(points, usage.summer)
    else
        return get_fuel_usage_by_track(points, usage.winter)
    end
end

function append_fuel_calc(device, rows, limits)
    local cjson = require "cjson"
    local dates = {}
    local times = utils.gsplit(limits, ";")
    local from = 1;
    local usageString = store.get_fuel_usage(device);
    if usageString == "" then
        return
    end
    local usage = cjson.decode(usageString);
    if not usage.summer and not usage.winter then
        return
    end
    local seasons = prepare_seasons(store.get_setting('seasons'));
    local time_index = 1
    while #times > #rows and time_index <= #rows do
        if math.abs(times[time_index] -
                rows[time_index].timestamp) > 86400/2 then
            table.remove(times, time_index)
        else
            time_index = time_index + 1
        end
    end;
    while from <= #rows do
        local requests = {}
        for i=from,math.min(from+99,#rows) do
            if times[i+1] ~= nil then
                requests[i-from+1] = {"/x.x", {method = ngx.HTTP_POST, body ="c=4&i="..device
                        .."&x="..times[i].."&y="..(tonumber(times[i+1])-1)} }
            end
        end
        local resps = { ngx.location.capture_multi(requests) }
        for i=1,#resps do
            rows[i+from-1].fuel = get_fuel_usage_by_history_response(resps[i], usage,
                is_summer(times[i], seasons))
        end
        from = from + 100;
    end
    -- get tracks for each date
    -- calculate fuel usage
    -- append it to each chunk
end

function append_fuel_sensors(device, rows, from, to, lang)
    local lang_code = 1 --ru
    if lang == "ua" then
        lang_code = 2
    elseif lang == "en" then
        lang_code = 0;
    end
    local res = ngx.location.capture('/x.x', {method = ngx.HTTP_POST,
        body = "l="..lang_code.."&c=28&i="..device.."&x="..from.."&y="..to})
    local chunks = utils.gsplit(res.body)

    local index = 1

    while index <= #rows do
        local current_row = rows[index]
        local next_row = rows[index + 1]
        local fuel_used = 0;

        if #chunks > 2 then
            for k,row in pairs(chunks) do
                if row~="" then
                    local parts = utils.gsplit(row, ";");
                    local status = parts[1]
                    local timestamp_from = tonumber(parts[2])
                    local fuel_from = parts[9]
                    local fuel_to = parts[10]
    
                    if status == "3" and fuel_from ~= nil and fuel_to ~= nil and timestamp_from >= current_row.timestamp then

                        if next_row ~= nil then
                            if timestamp_from < next_row.timestamp then
                                fuel_used = fuel_used + tonumber(fuel_from) - tonumber(fuel_to)
                            end
                        else
                            fuel_used = fuel_used + tonumber(fuel_from) - tonumber(fuel_to)
                        end
                    end
                end
            end
        end

        current_row.fuel = fuel_used
        index = index + 1
    end

end

function get_visited_zones(id_list, ts_from, ts_to)
    local ids = utils.gsplit(id_list, ",")
    local header
    local data = {}
    local from = 1
    -- для каждого авто
    while from <= #ids do
        local requests = {}
        for i=from,math.min(from+99, #ids) do
            requests[i-from+1] = {"/x.x", {method = ngx.HTTP_POST, body ="c=28&i="..ids[i]
                    .."&x="..ts_from.."&y="..ts_to} }
        end
        local resps = { ngx.location.capture_multi(requests) }
        for i=1,#resps do
            local response = resps[i];
            local chunks = utils.gsplit(response.body)
            table.remove(chunks, 1)
            table.remove(chunks, 1)
            local stops = processStops(chunks,"ru", "")
            for j=1,#stops.stops do
                if stops.stops[j].latitude then
                    data[#data+1] = stops.stops[j]
                end
            end
        end
        from = from + 100;
        header = resps[1].header
    end
    utils.forward_headers(header)
    local zones = store.get_visited_zones(data)
    return zones
end

function router.process()
    local args = ngx.req.get_post_args()
    if args["v"]=="3" then
        if args["intervals"] then
            store.set_settings({intervals = args["intervals"]})
            ngx.print("1001\n\n");
        end
        if args["seasons"] then
            store.set_settings({seasons = args["seasons"]})
            ngx.print("1009\n\n");
        end
        if args["settings"] then
            local cjson = require "cjson"
            local settings = cjson.decode(args["settings"])
            store.set_settings(settings)
            ngx.print("1005\n\n");
        end
        if args["fuel"] then
            store.set_fuel_usage(args["id"], args["fuel"])
            ngx.print("1005\n\n");
        end
        -- установка абонентской платы для машины
        if args["carSubscriberPlan"] then
          store.set_car_subscriber_plan(args["id"], args["carSubscriberPlan"])
          ngx.print("1005\n\n");
        end
      -- установка абонентской платы для машин
        if args["carsSubscriberPlans"] then
          local cjson = require "cjson"
          local carsSubscriberPlans = cjson.decode(args["carsSubscriberPlans"])
          for i=1,#carsSubscriberPlans do
            store.set_car_subscriber_plan(carsSubscriberPlans[i].id, carsSubscriberPlans[i].subscriberPlan)
          end
          ngx.print("1005\n\n");
        end
        -- get cars subscriber plans data
        if args["carsIdsForSubscriberPlansData"] then
          if utils.isempty(args["carsIdsForSubscriberPlansData"]) then
            ngx.print("1020\n\n");
            ngx.print("[]");
          else
            local carsData = store.get_cars_subscriber_plans_data(args["carsIdsForSubscriberPlansData"]);
            local from = 1;
            while from <= #carsData do
              local requests = {}
              for i=from,math.min(from+99,#carsData) do
                requests[i-from+1] = {"/x.x", {method = ngx.HTTP_POST, body ="c=7&i="..carsData[i].id} }
              end
              local resps = { ngx.location.capture_multi(requests) }
              for i=1,#resps do
                local resp = resps[i]
                local chunks = utils.gsplit(resp.body)
                local sett = parse_account_settings(chunks[4])
                if sett ~= nil then
                  carsData[i+from-1]["simNumber"] = sett["simNumber"]
                  carsData[i+from-1]["name"] = sett["name"]
                end
              end
              from = from + 100;
            end
            local cjson = require "cjson";
            ngx.print("1020\n\n");
            ngx.print(cjson.encode(carsData));
          end
        end
        -- get car subscriber plans
        if args["carSubscriberPlansYear"] then
          local res = store.get_car_subscriber_plans(args["carSubscriberPlansYear"]);
          local cjson = require "cjson";
          ngx.print("1020\n\n");
          ngx.print(cjson.encode(res));
        end
        -- установка абонентской платы для машины
        if args["salesManWorkingTime"] then
          store.set_car_salesman_working_time(args["id"], args["salesManWorkingTime"])
          ngx.print("1005\n\n");
        end
        -- встановлення геозон початку і кінця маршруту
        if args["setCarZones"] and store.has_permission("logistics") then
          store.set_car_zones(args["id"], args["startZoneId"], args["endZoneId"])
          ngx.print("1005\n\n");
        end
        -- get cars zones data
        if args["carsIdsForLogisticData"] then
          local carsData = store.get_cars_logistic_data(args["carsIdsForLogisticData"]);
          local cjson = require "cjson";
          ngx.print("1020\n\n");
          ngx.print(cjson.encode(carsData));
        end
        if args["setCargoCapacity"] and store.has_permission("logistics") then
          store.set_car_cargo_capacity(args["id"], args["setCargoCapacity"])
          ngx.print("1005\n\n");
        end
        if args["setCarImpulse"] then
          store.set_car_impulse(args["id"], args["setCarImpulse"])
          ngx.print("1005\n\n");
        end
        -- get user settings
        if args["getUserSettings"] then
          local res = store.get_user_settings(args["getUserSettings"]);
          local iconv = require(ngx.var.lua_mod_prefix.."iconv");
        -- todo check if property exist
        --  res.loginDescription = iconv.Utf8ToAnsi(tostring(res.loginDescription));
          local cjson = require "cjson";
          ngx.print("1020\n\n");
          ngx.print(cjson.encode(res));
        end
        -- set user settings
        if args["setUserSettings"] then
          local cjson = require "cjson";
          local userSettings = cjson.decode(args["setUserSettings"]);
          store.set_user_settings(userSettings)
          ngx.print("1005\n\n");
        end
        -- get user settings by params
        if args["getUsersSettingsByParams"] then
          local cjson = require "cjson";
          local params = cjson.decode(args["getUsersSettingsByParams"]);
          local res = store.get_users_settings_by_params(params)
          ngx.print("1020\n\n");
          ngx.print(cjson.encode(res));
        end
        -- todo: check permissions for routes
        -- save route
        if args["saveRoute"] and store.has_permission("logistics") then
          local cjson = require "cjson";
          local route = cjson.decode(args["saveRoute"]);
          store.save_route(route)
          ngx.print("1005\n\n");
        end
        -- get routes
        if args["getRoutes"] and store.has_permission("logistics") then
          local cjson = require "cjson";
          local res = store.get_routes()
          ngx.print("1020\n\n");
          ngx.print(cjson.encode(res));
        end
        -- get routes by car id (no login verificarion)
        if args["getRoutesByCarId"] and store.has_permission("logistics") then
          local cjson = require "cjson";
          local res = store.get_routes_by_car(args["getRoutesByCarId"])
          ngx.print("1020\n\n");
          ngx.print(cjson.encode(res));
        end
        -- get route
        if args["getRoute"] and store.has_permission("logistics") then
          local cjson = require "cjson";
          local res = store.get_route(args["getRoute"])
          ngx.print("1020\n\n");
          ngx.print(cjson.encode(res));
        end
        -- get route for car (no login verificarion)
        if args["getRouteForCar"] and store.has_permission("logistics") then
          local cjson = require "cjson";
          local res = store.get_route_for_car(args["getRouteForCar"], args["carId"])
          ngx.print("1020\n\n");
          ngx.print(cjson.encode(res));
        end
        -- delete route
        if args["deleteRoute"] and store.has_permission("logistics") then
          store.delete_route(args["deleteRoute"])
          ngx.print("1004\n\n")
          ngx.print(args["deleteRoute"])
        end
        if args["report"] and store.has_permission("reports") then
            local cjson = require "cjson"
            local report = form_report(args["from"], args["to"], args["ids"], args["report"], args["limits"]);
            ngx.print("1002\n\n");
            ngx.print(cjson.encode(report))
        end
        -- гео зоны
        if args["zone"] and store.has_permission("geo-zones")  then
            local cjson = require "cjson";
            local zone = cjson.decode(args["zone"])
            -- todo: strip tags from color and name
            zone = store.save_zone(zone)
            ngx.print("1003\n\n")
            ngx.print(cjson.encode(zone))
        end
        if args["zoneId"] and store.has_permission("geo-zones") then
            store.delete_zone(args["zoneId"])
            ngx.print("1004\n\n")
            ngx.print(args["zoneId"])
        end
        if args["visitors"] and store.has_permission("geo-visits") then
            local data = get_visited_zones(args["visitors"], args["from"], args["to"]);
            ngx.print("1011\n\n")
            local cjson = require "cjson"
            ngx.print(cjson.encode(data))
        end
        -- отчет баланса на карточках
        if args["cardBalance"] and store.has_permission("card-balance-summary") then
            local balance = get_account_card_balance(args["cardBalance"])
            ngx.print("1006\n\n")
            local cjson = require "cjson"
            ngx.print(cjson.encode(balance))
        end
        -- получение прав отдельного дочернего пользователя
        if args["userPermissionsLogin"] and store.is_child_user(args["userPermissionsLogin"]) then
            local permissions = store.get_permissions(args["userPermissionsLogin"])
            ngx.print("1007\n\n")
            ngx.print(permissions)
        end
        --фильтрация трекера
        if args["filterTracker"] then
            store.filter_device(args["id"], args["filterTracker"])
            ngx.print("1013\n\n")
        end
        -- блокровка дочернего пользователя
        -- блокировку реализуем как право быть заблокированным
        if args["blockUser"] and store.is_child_user(args["id"]) then
            store.set_permissions(args["id"], {beBlocked = args["blockUser"]=="true"})
            ngx.print("1014\n\n")
        end
        -- задание прав отдельному дочернему пользователю
        if args["permissions"] and store.is_child_user(args["permissionsLogin"]) then
            local cjson = require "cjson"
            local permissions = cjson.decode(args["permissions"])
            local parsed_permissions = {}
            for k,v in pairs(permissions) do
                parsed_permissions[k] = v and store.has_permission(k)
            end
            local login = args["permissionsLogin"]
            store.set_permissions(login, parsed_permissions)
            ngx.print("1008\n\n")
            ngx.print(login)
        end
        if args["distance"] then -- get distance
            local res = ngx.location.capture('/x.x', {method = ngx.HTTP_POST,
                            body = "c=5&i="..args["device"].."&x="..args["from"].."&y="..args["to"]})
            local response = res.body;
            local chunks = utils.gsplit(res.body)
            table.remove(chunks, 1)
            table.remove(chunks, 1)
            local data = processDistance(chunks, args["lang"]).rows
            if store.has_permission("fuel-calc") then
                append_fuel_calc(args["device"], data, args["limits"])
            end
            local cjson = require "cjson"
            ngx.print("1010\n\n")
            ngx.print(cjson.encode(data))
        end
        if args["schedules"] then --список ml
            local data = {}
            if store.has_permission("schedules") then
                data = store.get_schedules()
            end
            local cjson = require "cjson"
            ngx.print("1012\n\n")
            ngx.print(cjson.encode(data))
        end
        if args["scheduleName"] then --сохранение ml
            local data = {}
            if store.has_permission("schedules") then
                store.save_schedule(args["scheduleName"], args["list"], args["id"])
                data = store.get_schedules()
            end
            local cjson = require "cjson"
            ngx.print("1012\n\n")
            ngx.print(cjson.encode(data))
        end
        if args["assignedSchedules"] then -- список назначеных ml
            local data = {}
            if store.has_permission("schedules") then
                data = store.get_assigned_schedules(args["assignedSchedules"], nil, nil)
            end
            local cjson = require "cjson"
            ngx.print("1015\n\n")
            ngx.print(cjson.encode(data))
        end
        if args["assignSchedule"] then -- назначение ml
            local data = {}
            if store.has_permission("schedules") then
                store.assign_schedule(args["assignSchedule"], args["carId"], args["date"])
                data = store.get_assigned_schedules(args["date"], nil, nil)
            end
            local cjson = require "cjson"
            ngx.print("1015\n\n")
            ngx.print(cjson.encode(data))
        end
        if args["scheduleReport"] then
            local data = {}
            if store.has_permission("schedules") then
                data = form_report_schedule(args["from"], args["to"], args["scheduleReport"], args["schedule"], args["l"])
            end
            local cjson = require "cjson"
            ngx.print("1016\n\n")
            ngx.print(cjson.encode(data))
        end
        if args["format"] then -- export
            local type = args["type"]
            local cp1251 = 'true'
            local data
            if type == "stops" then
                local lang_code = 1 --ru
                if args["lang"] == "ua" then
                    lang_code = 2
                elseif args["lang"] == "en" then
                    lang_code = 0;
                end
                local res = ngx.location.capture('/x.x', {method = ngx.HTTP_POST,
                    body = "l="..lang_code.."&c=28&i="..args["device"].."&x="..args["from"].."&y="..args["to"]})
                --issue refs #542
                local history = ngx.location.capture('/x.x', {method = ngx.HTTP_POST,
                    body = "c=4&i="..args["device"].."&x="..args["from"].."&y="..args["to"]})
                local historyChunks = utils.gsplit(history.body)
                table.remove(historyChunks, 1)
                table.remove(historyChunks, 1)
                table.remove(historyChunks, 1)
                history = get_history_points(historyChunks)
                local chunks = utils.gsplit(res.body)
                table.remove(chunks, 1)
                table.remove(chunks, 1)
                data = processStops(chunks, args["lang"], history)
                data = add_geozones_to_stops(data, cp1251)
                local iconv = require(ngx.var.lua_mod_prefix.."iconv")
                data.deviceName = iconv.Utf8ToAnsi(args["deviceName"])
                local info = store.get_device_info(args["device"])
                if info ~= nil then
                    data.summary.fuelSettings = info.fuel
                    local seasons = prepare_seasons(store.get_setting('seasons'))
                    data.summary.isSummer = is_summer(args["from"], seasons)
                    ngx.log(ngx.ERR, "is summer:",data.summary.isSummer)
                end
                data.tsFrom = args["from"];
                data.tsTo = args["to"];
                data.subtype = args["subtype"];
            end
            if type == "distance" then
                local iconv = require(ngx.var.lua_mod_prefix.."iconv")
                local res = ngx.location.capture('/x.x', {method = ngx.HTTP_POST,
                    body = "c=5&i="..args["device"].."&x="..args["from"].."&y="..args["to"]})
                local chunks = utils.gsplit(res.body)
                table.remove(chunks, 1)
                table.remove(chunks, 1)
                data = processDistance(chunks, args["lang"])
                if store.has_permission("fuel-calc") then
                    local cjson = require "cjson"
                    local usageString = store.get_fuel_usage(args["device"]);

                    local usage = cjson.decode(usageString);
                    if not usage.summer and not usage.winter then
                        append_fuel_sensors(args["device"], data.rows, args["from"], args["to"], args["lang"])
                    else
                        append_fuel_calc(args["device"], data.rows, args["limits"])
                    end
                end

                data.tsFrom = args["from"];
                data.tsTo = args["to"];
                data.deviceName = iconv.Utf8ToAnsi(args["deviceName"])
            end
            if type == "report" then
                data = {
                    lang = args['lang'],
                    type = 'report',
                    rows = form_report(args["from"], args["to"], args["device"], args["report-name"], args["limits"]),
                    from = args["from"],
                    to = args["to"],
                    names = args["names"]
                }
                cp1251 = 'false'
            end
            if args["format"]=="xls" then
                local cjson = require "cjson"
                local res = ngx.location.capture('/xls?cp1251='..cp1251, { method = ngx.HTTP_POST,
                    body = cjson.encode(data)});
                utils.forward_headers(res.header)
                ngx.print(res.body)
            end
        end
        return ""
    end
end

return router
