local utils = {}

function utils.gsplit(s, sep)
    local res = {}
    local lasti = 0
    sep = sep or "\n"
    for v,i in s:gmatch("(.-)"..sep.."()") do
        res[#res + 1] = v
        lasti = i
    end
    res[#res + 1] = s:sub(lasti)
    return res
end

function utils.forward_headers(header)
    for k,v in pairs(header) do
       ngx.header[k] = v
    end
end

function utils.stripTags(text)
    return string.gsub(text,"<.->","");
end

function utils.has_session()
    ngx.ctx.s_session = ngx.var.cookie_MGS;
    return ngx.ctx.s_session~=nil and ngx.ctx.s_session~="";
end

function utils.force_logout()
    ngx.log(ngx.ERR, "has session:",utils.has_session())
    ngx.log(ngx.ERR, "forcing logout, no login for sessio ", ngx.ctx.s_session);
    ngx.header["Set-Cookie"] = "MGS=; Path=/; Expires=" .. ngx.cookie_time(ngx.time() - 8640000)
    ngx.say("0\n0\n")
    ngx.exit(ngx.OK)
end

function utils.date_to_timestamp(date_string)
    local year,month,day = date_string:match("(%d+).(%d+).(%d+)")
    return os.time({day=day,month=month,year=year,hour=0,min=0,sec=0})
end

function utils.isempty(s)
  return s == nil or s == ''
end

return utils
