local store = {}
local utils = require(ngx.var.lua_mod_prefix.."utils")

-- mysql:
local db_host = "127.0.0.1"
local db_port = 3306
local db_user = "megagps"
local db_base = "megagps"
local db_pass = "sPsuLj9R7jfDLRCy"


function init_redis()
    if ngx.ctx.s_red~=nil then
        return true
    end
    local redis = require "resty.redis"
    ngx.ctx.s_red = redis:new()
    ngx.ctx.s_red:set_timeout(1000)
    local ok, err = ngx.ctx.s_red:connect("127.0.0.1", 6379)
    if not ok then
        ngx.log(ngx.ERR, "Redis problem", err)
        ngx.ctx.s_red = nil
    end
    return ok
end

function release_redis()
    if ngx.ctx.s_red~=nil then
        ngx.ctx.s_red:set_keepalive(3000, 100)
        ngx.ctx.s_red = nil
    end
end

function sessionKey(session)
    return "gps:sess:"..session;
end

function store.update_session(login, session)
    if not login then
        login = ngx.ctx.s_login
    else
        ngx.ctx.s_login = login
    end
    if not session then
        session = ngx.ctx.s_session
    else
        ngx.ctx.s_session = session
    end
    ngx.ctx.s_red:setex(sessionKey(session),86400*10, login)
end

function store.save_child_users(login, child_users)
    if init_mysql() then
        local childs = ngx.quote_sql_str("|"..table.concat(child_users,'|').."|")
        ngx.ctx.s_mysql:query("insert into `child_users` (`user`, `childs`) values('"..login.."',"..childs
                ..") on duplicate key update `childs` = "..childs)
    end
end

function store.is_child_user(login)
    if init_mysql() then
        local res = ngx.ctx.s_mysql:query("select count(*) as `count` from `child_users` where `user`="
                ..ngx.quote_sql_str(ngx.ctx.s_login).." and `childs` like "..ngx.quote_sql_str("%|"..login.."|%"));
        return res[1]["count"] == "1"
    end
    return false
end

function store.get_point_name(latitude, longitude)
    if init_mysql() then
        local res, err, errno, sqlstate = ngx.ctx.s_mysql:query("select get_point_name("
                ..ngx.quote_sql_str(ngx.ctx.s_login)..",POINT("
                ..longitude..","..latitude..")) as get_point_name")

--ngx.log(ngx.ERR, res)
--ngx.log(ngx.ERR, "select get_point_name("..ngx.quote_sql_str(ngx.ctx.s_login)..",POINT("..longitude..","..latitude..")) as get_point_name")

--	if res==nil then
--		ngx.log(ngx.ERR, "select get_point_name("..ngx.quote_sql_str(ngx.ctx.s_login)..",POINT("..longitude..","..latitude..")) as get_point_name")
--	end
        --ngx.log(ngx.ERR, "looking for point:"..latitude..","..longitude)
	if res~=nil then
	        local name = res[1]["get_point_name"]
	        return name;
	end
    end
    return ngx.null
end

function store.get_setting(name)
    if init_mysql() then
        local res = ngx.ctx.s_mysql:query("select `value` from `settings` where `login`="
                ..ngx.quote_sql_str(ngx.ctx.s_login).." and `param`="..ngx.quote_sql_str(name))
        if #res == 1 then
            local value = res[1]['value']
            if string.sub(value,1,1) == "{" then
                local cjson = require "cjson"
                value = cjson.decode(value)
            end
            return value
        end
    end
    return ""
end

function store.get_visited_zones(stops)
    if init_mysql() then
        local points = {}
        for i=1,#stops do
            points[#points+1] = "Point("..stops[i].longitude..","..stops[i].latitude..")"
        end
        local res = ngx.ctx.s_mysql:query("call get_visited_zones("
                ..ngx.quote_sql_str(ngx.ctx.s_login)..",MultiPoint("
                ..table.concat(points, ",").."))")
        local data = {}
        for i=1,#res do
            data[#data+1] = res[i]["id"];
        end
        return data;
    end
    return false
end

function store.get_settings()
    if init_mysql() then
        local res = ngx.ctx.s_mysql:query("select `param`, `value` from `settings` where `login`="..ngx.quote_sql_str(ngx.ctx.s_login))
        local cjson = require "cjson"
        local data = {}
        for _,v in pairs(res) do
            local val = v['value'];
            if string.sub(val,1,1) == "{" then
                val = cjson.decode(val)
            end
            data[v['param']]=val
        end

        return cjson.encode(data)
    end
    return ""
end

function store.get_permissions(login)
    if init_mysql() then
        local res = ngx.ctx.s_mysql:query("select `permission` from `permissions` where `allowed`=1 and `login`="..ngx.quote_sql_str(login))
        local cjson = require "cjson"
        local data = {}
        for _,v in pairs(res) do
            data[#data+1] = v['permission'];
        end
        return cjson.encode(data)
    end
    return ""
end

function store.has_permission(permission_name)
    if init_mysql() then
        local res = ngx.ctx.s_mysql:query("select count(*) as `count` from `permissions` where `login`="
                ..ngx.quote_sql_str(store.get_login())
                .." and `permission`="..ngx.quote_sql_str(permission_name).." and `allowed`=1")
        return res[1]["count"] == "1"
    end
    return false
end

function store.set_settings(settings)
    if init_mysql() then
        for k,v in pairs(settings) do
            ngx.ctx.s_mysql:query("insert into `settings` (`login`,`param`,`value`) values("..
                    ngx.quote_sql_str(ngx.ctx.s_login)..","..ngx.quote_sql_str(k)..","..
                    ngx.quote_sql_str(v)..") on duplicate key update value="..ngx.quote_sql_str(v))
        end
    end
    -- return ngx.ctx.s_red:set(settingsKey(ngx.ctx.s_login), settings)
end

function store.set_permissions(login, permissions)
    if init_mysql() then
        for k,v in pairs(permissions) do
            local value;
            if v then
                value = "1"
            else
                value = "0"
            end
            ngx.ctx.s_mysql:query("insert into `permissions` (`login`,`permission`,`allowed`) values("..
                    ngx.quote_sql_str(login)..","..ngx.quote_sql_str(k)..","..
                    ngx.quote_sql_str(value)..") on duplicate key update allowed="..ngx.quote_sql_str(value))
        end
    end
    -- return ngx.ctx.s_red:set(settingsKey(ngx.ctx.s_login), settings)
end

function store.get_login()
    if ngx.ctx.s_login then
        return ngx.ctx.s_login
    end
    if not utils.has_session() or not init_redis() then
        return nil
    end
    local err
    ngx.ctx.s_login, err = ngx.ctx.s_red:get(sessionKey(ngx.ctx.s_session))
    if err then
        ngx.log(ngx.ERR, "Redis problem on get login stage:", err)
    end
    ngx.log(ngx.ERR, "get_login:", ngx.ctx.s_login)
    return ngx.ctx.s_login
end

function init_mysql()
    if ngx.ctx.s_mysql~=nil then
        return true
    end
    local mysql = require "resty.mysql"
    local db, err = mysql:new()
    if not db then
        ngx.log(ngx.ERR, "failed to instantiate mysql: ", err)
        return false;
    end
    local ok, err, errno, sqlstate = db:connect{
        host = db_host,
        port = db_port,
        database = db_base,
        user = db_user,
        password = db_pass,
        max_packet_size = 1024 * 1024,
        --compact_arrays = true,
    }
    if not ok then
        ngx.log(ngx.ERR, "failed to connect: ", err, ": ", errno, " ", sqlstate)
        return false;
    end
    ngx.ctx.s_mysql = db;
    db:query("set names utf8")
    db:query("SET time_zone = 'Europe/Kiev';")
    return true;
end

function release_mysql()
    if ngx.ctx.s_mysql ~= nil then
        ngx.ctx.s_mysql:set_keepalive(3000, 20)
        ngx.ctx.s_mysql = nil
    end
end

function store.save_speed_limit(device, warn, limit)
    if init_mysql() then
        device = tonumber(device);
        warn = tonumber(warn);
        limit = tonumber(limit);
        ngx.ctx.s_mysql:query("insert into `devices` (`id`, `speed_warn`, `speed_limit`) values("..device..","
                ..warn..","..limit..") on duplicate key update `speed_warn`="..warn..", `speed_limit`="..limit)
    end
end

function store.filter_device(device, state)
    if init_mysql() then
        device = tonumber(device);
        state = tonumber(state);
        ngx.ctx.s_mysql:query("insert into `devices` (`id`, `isFilter`) values("..device..","
                ..state..") on duplicate key update `isFilter`="..state)
    end
end

function store.save_notes(device, notes)
    if init_mysql() then
        device = tonumber(device)
        notes = ngx.quote_sql_str(notes)
        ngx.ctx.s_mysql:query("insert into `devices` (`id`, `notes`) values("..device..","
                ..notes..") on duplicate key update `notes`="..notes)
    end
end

function store.save_short_name(device, short)
    if init_mysql() then
        device = tonumber(device)
        short = ngx.quote_sql_str(short)
        ngx.ctx.s_mysql:query("insert into `devices` (`id`, `short`) values("..device..","
                ..short..") on duplicate key update `short`="..short)
    end
end

function store.get_schedule_by_id(id)
    return ngx.ctx.s_mysql:query("select * from `schedules` where `id`="..id)[1]
end

function store.get_zones_by_schedule_id(id)
    if init_mysql() then
        local ids = ngx.ctx.s_mysql:query("select list from `schedules` where `id`="..id)[1].list
        local res = ngx.ctx.s_mysql:query("select id, name from `geozones` where `id` in ("..ids..") order by `name` desc")
        return res
    end
    return ""
end

function store.get_zones(logins)
    if init_mysql() then
        local res = ngx.ctx.s_mysql:query("select id, login, color, name, days, AsWKT(wkt) wkt from `geozones` where `login` in ("..logins..") order by `name` desc")
        local cjson = require "cjson"
        return cjson.encode(res)
    end
    return ""
end

function store.delete_zone(id)
    if init_mysql() then
        id = tonumber(id)
        local login = ngx.quote_sql_str(ngx.ctx.s_login)
        ngx.ctx.s_mysql:query("delete from `geozones` where login="..login.." and id="..id)
    end
end

function store.get_schedules()
    if init_mysql() then
        local login = ngx.quote_sql_str(ngx.ctx.s_login)
        return ngx.ctx.s_mysql:query("select `id`, `name`, list from `schedules` where login="..login)
    end
end

function store.save_schedule(name, list, id)
    if init_mysql() then
        local login = ngx.quote_sql_str(ngx.ctx.s_login)
        list = ngx.quote_sql_str(list)
        name = ngx.quote_sql_str(name)
        if id then
            id = ngx.quote_sql_str(id)
            ngx.ctx.s_mysql:query("update `schedules` set list="..list..", `name`="..name.." where id="..id.." and login="..login)
        else
            ngx.ctx.s_mysql:query("insert into `schedules` (`login`,`name`,`list`) values("..login..","..name..","..list..")")
        end
    end
end

function store.assign_schedule(scheduleId, carId, date)
    if init_mysql() then
        carId = ngx.quote_sql_str(carId)
        scheduleId = ngx.quote_sql_str(scheduleId)
        date = ngx.quote_sql_str(date)
        local login = ngx.quote_sql_str(ngx.ctx.s_login)
        ngx.ctx.s_mysql:query("insert into `assigned_schedules` (`carId`, `scheduleId`, `date`, `login`) values("..carId..","..
                scheduleId..",DATE(FROM_UNIXTIME("..date..")),"..login..")")
    end
end

function store.get_assigned_schedules(date, to, ids)
    if init_mysql() then
        date = ngx.quote_sql_str(date)
        local login = ngx.quote_sql_str(ngx.ctx.s_login)
        local condition
        if to ~= nil then
            to = ngx.quote_sql_str(to)
            for i=1,#ids do
                ids[i] = tonumber(ids[i])
            end
            local list = table.concat(ids,",")
            condition = "`date`>=DATE(FROM_UNIXTIME("..date..")) and `date`<=DATE(FROM_UNIXTIME("..to..")) and `login`="..login.." and carId in ("..list..")"
        else
            condition = "`date`=DATE(FROM_UNIXTIME("..date..")) and `login`="..login
        end
        local res, err, errno, sqlstate = ngx.ctx.s_mysql:query("select * from `assigned_schedules` where "..condition)
        if not res then
            ngx.log(ngx.ERR, "bad result: "..err..": "..errno..": "..sqlstate..".")
            return nil
        end
        return res;
    end
end

function store.save_zone(zone)
    if init_mysql() then
        local wkt = ngx.quote_sql_str(zone["wkt"])
        local color = ngx.quote_sql_str(zone["color"])
        local login = ngx.quote_sql_str(ngx.ctx.s_login)
        local name = ngx.quote_sql_str(zone["name"])
        local days = ngx.quote_sql_str(zone["days"])
        local res, err, errno, sqlstate;
        zone["login"] = ngx.ctx.s_login
        -- todo: handle db failure
        if zone["id"] then -- update
            local id = tonumber(zone["id"])
            res = ngx.ctx.s_mysql:query("update `geozones` set color="..color
                    .." , wkt=GeomFromText("..wkt.."), name="..name..", days="..days.." where login="..login.." and id="..id)
        else -- new zone
            res, err, errno, sqlstate = ngx.ctx.s_mysql:query("insert into `geozones` (`login`, `name`, `color`, `wkt`, `days`) values("
                    ..login..","..name..","..color..",GeomFromText("..wkt.."), "..days..")")
            if not res then
                ngx.log(ngx.ERR, "bad result: ".. err..": ".. errno.. ": ".. sqlstate.. ".")
            end
            zone["id"] =  res.insert_id
        end
        return zone
    end
end

function store.get_device_info(device)
    if init_mysql() then
        device = tonumber(device);
        local res, err, errno, sqlstate = ngx.ctx.s_mysql:query("select `speed_warn`, `speed_limit`, `short`, `fuel`, `isFilter`, `subscriberPlan`, `startZoneId`, `endZoneId`, `cargoCapacity`, `impulse`, `salesManWorkingTime`, `notes` from `devices` where `id`="..device)
        if not res then
            ngx.log(ngx.ERR, "bad result: "..err..": "..errno..": "..sqlstate..".")
            return
        end
        return res[1];
    end
end

function store.get_fuel_usage(device)
    if init_mysql() then
        device = tonumber(device);
        local res, err, errno, sqlstate = ngx.ctx.s_mysql:query("select `fuel` from `devices` where `id`="..device)
        if not res then
            ngx.log(ngx.ERR, "bad result: "..err..": "..errno..": "..sqlstate..".")
            return
        end
        return res[1]["fuel"];
    end
end

function store.get_bulk_fuel_usage(devices)
    if init_mysql() then
        for i=1,#devices do
            devices[i] = tonumber(devices[i])
        end
        local list = table.concat(devices,",")
        local res, err, errno, sqlstate = ngx.ctx.s_mysql:query("select `id`, `fuel` from `devices` where `id` in ("..list..") order by field(id,"..list..")")
        if not res then
            ngx.log(ngx.ERR, "bad result: "..err..": "..errno..": "..sqlstate..".")
            return
        end
        local cjson = require "cjson"
        local usage = {}
        for i=1,#res do
            if res[i].fuel ~= "" then
                usage[res[i].id] = cjson.decode(res[i].fuel);
            end
        end
        return usage;
    end
end

function store.set_fuel_usage(device, usage)
    if init_mysql() then
        device = tonumber(device);
        usage = ngx.quote_sql_str(usage)
        ngx.ctx.s_mysql:query("insert into `devices` (`id`, `fuel`) values("..device..","
                ..usage..") on duplicate key update `fuel`="..usage)
    end
end

function store.get_bulk_speed_limit(devices)
    if init_mysql() then
        for i=1,#devices do
            devices[i] = tonumber(devices[i])
        end
        local list = table.concat(devices,",")
        local res, err, errno, sqlstate = ngx.ctx.s_mysql:query("select `id`,`speed_warn`, `speed_limit`, `short` from `devices` where `id` in ("..list..") order by field(id,"..list..")")
        if not res then
            ngx.log(ngx.ERR, "bad result: "..err..": "..errno..": "..sqlstate..".")
            return nil
        end
        return res;
    end
end

function store.set_car_subscriber_plan(deviceId, subscriberPlan)
  if init_mysql() then
    deviceId = tonumber(deviceId);
    subscriberPlan = ngx.quote_sql_str(subscriberPlan);
    ngx.ctx.s_mysql:query("insert into `devices` (`id`, `subscriberPlan`) values("..deviceId..","
      ..subscriberPlan..") on duplicate key update `subscriberPlan`="..subscriberPlan)
  end
end

function store.get_cars_subscriber_plans_data(deviceIds)
  if init_mysql() then

  local res, err, errno, sqlstate = ngx.ctx.s_mysql:query("select id, subscriberPlan from `devices` where `id` in ("..deviceIds..")")
  if not res then
    ngx.log(ngx.ERR, "bad result: "..err..": "..errno..": "..sqlstate..".")
    return nil
  end
  return res;
  end
end

function store.get_car_subscriber_plans(year)
  if init_mysql() then
    year = tonumber(year);
    local res, err, errno, sqlstate = ngx.ctx.s_mysql:query("select id, type, year, price from `car_subscriber_plans` where `year`="..year)
    if not res then
      ngx.log(ngx.ERR, "bad result: "..err..": "..errno..": "..sqlstate..".")
      return nil
    end
    if res==nil then -- если нет результата то нужно выбрать планы у которых наибольшый год, тоесть свежее
      local res1, err1, errno1, sqlstate1 = ngx.ctx.s_mysql:query("SELECT tt.* FROM `car_subscriber_plans` tt INNER JOIN"..
                                                                  "(SELECT id, type, MAX(year) AS MaxYear, price"..
                                                                  "FROM `car_subscriber_plans`) subscriberPlan"..
                                                                  "ON tt.year = subscriberPlan.MaxYear")
      if not res1 then
        ngx.log(ngx.ERR, "bad result: "..err1..": "..errno1..": "..sqlstate1..".")
        return nil
      end
      return res1;
    end
    return res;
  end
end

function store.set_car_salesman_working_time(deviceId, salesManWorkingTime)
    if init_mysql() then
      deviceId = tonumber(deviceId);
      salesManWorkingTime = ngx.quote_sql_str(salesManWorkingTime);
      ngx.ctx.s_mysql:query("insert into `devices` (`id`, `salesManWorkingTime`) values("..deviceId..","
        ..salesManWorkingTime..") on duplicate key update `salesManWorkingTime`="..salesManWorkingTime)
    end
  end

function store.set_car_zones(deviceId, startZoneId, endZoneId)
  if init_mysql() then
    deviceId = tonumber(deviceId);
    startZoneId = tonumber(startZoneId);
    endZoneId = tonumber(endZoneId);
    ngx.ctx.s_mysql:query("insert into `devices` (`id`, `startZoneId`, `endZoneId`) values("..deviceId..","
      ..startZoneId..","..endZoneId..") on duplicate key update `startZoneId`="..startZoneId..", `endZoneId`="..endZoneId)
  end
end

function store.get_cars_logistic_data(deviceIds)
  if init_mysql() then

    local res, err, errno, sqlstate = ngx.ctx.s_mysql:query("select id, startZoneId, endZoneId, cargoCapacity from `devices` where `id` in ("..deviceIds..")")
    if not res then
      ngx.log(ngx.ERR, "bad result: "..err..": "..errno..": "..sqlstate..".")
      return nil
    end
    return res;
  end
end

function store.set_car_cargo_capacity(deviceId, cargoCapacity)
  if init_mysql() then
    deviceId = tonumber(deviceId);
    cargoCapacity = ngx.quote_sql_str(cargoCapacity);
    ngx.ctx.s_mysql:query("insert into `devices` (`id`, `cargoCapacity`) values("..deviceId..","
      ..cargoCapacity..") on duplicate key update `cargoCapacity`="..cargoCapacity)
  end
end

function store.set_car_impulse(deviceId, impulse)
  if init_mysql() then
    deviceId = tonumber(deviceId);
    impulse = tonumber(impulse);
    ngx.ctx.s_mysql:query("insert into `devices` (`id`, `impulse`) values("..deviceId..","
      ..impulse..") on duplicate key update `impulse`="..impulse)
  end
end

function store.get_user_settings(login)
  if init_mysql() then
    local res, err, errno, sqlstate = ngx.ctx.s_mysql:query("select login, category, year, year, sequenceNumber, `group`, loginDescription from `user_settings`"..
      " where `login`="..ngx.quote_sql_str(login))
    if not res then
      ngx.log(ngx.ERR, "bad result: "..err..": "..errno..": "..sqlstate..".")
      return nil
    end
    return res[1];
  end
end

function store.set_user_settings(userSettings)
  if init_mysql() then
    local login = ngx.quote_sql_str(userSettings["login"]);
    local category = ngx.quote_sql_str(userSettings["category"]);
    local year = userSettings["year"];
    local sequenceNumber = userSettings["sequenceNumber"];
    local group = ngx.quote_sql_str(userSettings["group"]);
    local loginDescription = ngx.quote_sql_str(userSettings["loginDescription"]);

    ngx.ctx.s_mysql:query("insert into `user_settings` (`login`,`category`,`year`,`sequenceNumber`, `group`, `loginDescription`) values("..
      login..","..category..","..
      year..","..sequenceNumber..","..group..","..loginDescription..") on duplicate key update category="..category..",year="..
      year..",sequenceNumber="..sequenceNumber..",`group`="..group..",loginDescription="..loginDescription)
  end
end


function store.get_users_settings_by_params(params)
  if init_mysql() then
    local res, err, errno, sqlstate = ngx.ctx.s_mysql:query("select login, category, year, year, sequenceNumber, `group`, loginDescription from `user_settings`"..
      " where `category`="..ngx.quote_sql_str(params.category).." and `group`="..ngx.quote_sql_str(params.group))
    if not res then
      ngx.log(ngx.ERR, "bad result: "..err..": "..errno..": "..sqlstate..".")
      return nil
    end
    return res;
  end
end

function store.save_route(route)
  if init_mysql() then
    local title = ngx.quote_sql_str(route["title"]);
    local data = ngx.quote_sql_str(route["data"]);
    local login = ngx.quote_sql_str(ngx.ctx.s_login);
    local carId = route["carId"];
    local isAccepted = tonumber(route["isAccepted"]);
    local timeCorrectionInCity = tonumber(route["timeCorrectionInCity"]);
    local timeCorrectionOutsideCity = tonumber(route["timeCorrectionOutsideCity"]);
    local routeComplexity = route["routeComplexity"];
    local dateTime = route["dateTime"];
    local res, err, errno, sqlstate;
    route["login"] = ngx.ctx.s_login;
    -- todo: handle db failure
    if route["id"] then -- update
      local id = tonumber(route["id"])
      res = ngx.ctx.s_mysql:query("update `routes` set carId="..carId
        .." , title="..title
        .." , dateTime="..dateTime
        .." , data="..data
        .." , isAccepted="..isAccepted
        .." , timeCorrectionInCity="..timeCorrectionInCity
        .." , timeCorrectionOutsideCity="..timeCorrectionOutsideCity
        .." , routeComplexity="..routeComplexity
        .." where login="..login.." and id="..id);
    else -- new route
      res, err, errno, sqlstate = ngx.ctx.s_mysql:query("insert into `routes` (`login`, `carId`, `title`, `dateTime`, `data`, `isAccepted`, `timeCorrectionInCity`, `timeCorrectionOutsideCity`, `routeComplexity`) values("
        ..login..","..carId..","..title..","..dateTime..","..data..","..isAccepted..","..timeCorrectionInCity..","..timeCorrectionOutsideCity..","..routeComplexity..")");
      if not res then
        ngx.log(ngx.ERR, "bad result: ".. err..": ".. errno.. ": ".. sqlstate.. ".");
      end
      route["id"] =  res.insert_id;
    end
    return route;
  end
end

function store.get_routes()
  if init_mysql() then
    local login = ngx.quote_sql_str(ngx.ctx.s_login);
    local res = ngx.ctx.s_mysql:query("select id, login, carId, title, dateTime, isAccepted from `routes` where `login`= "..login.." order by `dateTime` asc");
    return res;
  end
  return "";
end

function store.get_routes_by_car(carId)
    if init_mysql() then
      local res = ngx.ctx.s_mysql:query("select id, login, carId, title, dateTime, isAccepted from `routes` where `carId`= "..carId.." order by `dateTime` asc");
      return res;
    end
    return "";
  end

function store.get_route(id)
  if init_mysql() then
    id = tonumber(id);
    local login = ngx.quote_sql_str(ngx.ctx.s_login);
    local res = ngx.ctx.s_mysql:query("select id, login, carId, title, dateTime, data, isAccepted, timeCorrectionInCity, timeCorrectionOutsideCity, routeComplexity from `routes` where `login`= "..login.."and id="..id);
    return res[1];
  end
  return "";
end

function store.get_route_for_car(id, carId)
    if init_mysql() then
      id = tonumber(id);
      carId = tonumber(carId);
      local res = ngx.ctx.s_mysql:query("select id, login, carId, title, dateTime, data, isAccepted, timeCorrectionInCity, timeCorrectionOutsideCity, routeComplexity from `routes` where id="..id);
      return res[1];
    end
    return "";
  end

function store.delete_route(id)
  if init_mysql() then
    id = tonumber(id);
    local login = ngx.quote_sql_str(ngx.ctx.s_login);
    ngx.ctx.s_mysql:query("delete from `routes` where login="..login.." and id="..id);
  end
end

function store.init()
    return init_redis();
end

function store.release()
    release_redis();
    release_mysql();
end

return store;
