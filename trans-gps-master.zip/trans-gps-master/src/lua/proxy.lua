--package.path = ngx.var.root.."/lua/?.lua;"..package.path
local utils = require(ngx.var.lua_mod_prefix.."utils")
local store = require(ngx.var.lua_mod_prefix.."store")

local args = ngx.req.get_post_args()
local processed = false
local response

if args["route"] then -- OSRM
    local res = ngx.location.capture('/route.engine'..args["route"], {method = ngx.HTTP_GET})
    for k,v in pairs(res.header) do
       ngx.header[k] = v
    end
    processed = true;

    response = res.body
end

if args["mega"] then -- get fuel details
    local res = ngx.location.capture('/help.x', {method = ngx.HTTP_POST, body = "c=1&s="..args["limit"].."&i="..args["device"].."&x="..args["from"].."&y="..args["to"]})
    for k,v in pairs(res.header) do
       ngx.header[k] = v
    end
    processed = true;

    local code = "100";
    if args["onlyCnt"] == "1" then
        code = "110"
    end
    if args["onlyData"] == "1" then
        code = "111"
    end
    response = code..res.body
end

if args["v"]~="3" then
    local res = ngx.location.capture('/x.x', {method = ngx.HTTP_POST})
    response = res.body
    for k,v in pairs(res.header) do
       ngx.header[k] = v
    end

    if args and args["c"]=="1" and not args["i"] then  -- логин или проверка залогиненности, i - получение группы
        local chunks = utils.gsplit(response);
        if #chunks >= 3 and chunks[2] ~= "" and chunks[2] ~= "0"then
            local session = chunks[2]
            local login_chunks = utils.gsplit(chunks[3], ";")
            local login = login_chunks[2]
            local login_type = login_chunks[1]
            ngx.log(ngx.ERR, "login caugth:",login)
            processed = true;
            local settings = ""
            local zones = ""
            local permissions = ""
            local logins = "'"..login.."'"
            local child_users = {}
            if store.init() then
                for i=4,#chunks do--form logins list for zones selecting
                    local row = chunks[i]
                    local parts = utils.gsplit(row,";")
                    if parts[1] == "s" then
                        if parts[2]~="0" then
                            logins = logins..",'"..parts[3].."'"
                            child_users[#child_users+1] = parts[3]
                        end
                    else
                        logins = logins..",'"..parts[1].."'"
                    end
                end
                store.save_child_users(login, child_users)
                store.update_session(login, session)
                settings = store.get_settings()
                if store.has_permission("geo-zones") then
                    local iconv = require(ngx.var.lua_mod_prefix.."iconv")
                    zones = store.get_zones(logins)
                    --zones = iconv.Utf8ToAnsi(zones)
                else
                    zones = "[]"
                end

                permissions = store.get_permissions(login)
                store.release()
            end
            if not settings or settings==ngx.null or settings=="{}" then
                settings = '{"intervals":{"night":{"from":"00:00","to":"11:59"},"day":{"from":"12:00","to":"14:59"},"evening":{"from":"15:00","to":"23:59"}}}'
            end
            local configurable_permissions = "[]"
            if login_type == "0" then
                configurable_permissions = '["geo-zones","geo-visits","fuel-calc","schedules","reports","logistics"]'
            end
            local isBlocked = store.has_permission("beBlocked")
            local blocked = 0;
            if isBlocked then
                blocked = 1;
            end
            response = response
                    .."settings;"..settings .."\n"
                    .."zones;".. zones.."\n"
                    .."permissions;"..permissions.."\n"
                    .."configurable;"..configurable_permissions.."\n"
                    .."blocked;"..blocked
        end
    end
    if args and args["c"] == "7" then -- get settings
        local chunks = utils.gsplit(response);
        if #chunks >= 3 and chunks[4] ~= "" and chunks[4] ~= "0" then
            local deviceId = args["i"];
            local info = store.get_device_info(deviceId)
            local speedLimit
            local fuel
            local shortName
            local subscriberPlan
            local startZoneId
            local endZoneId
            local cargoCapacity
            local impulse
            local salesManWorkingTime
            local notes
            local _,partsCount = chunks[4]:gsub(";","")
            if info ~= nil then
                speedLimit = info["speed_limit"]
                fuel = info["fuel"]
                shortName = info["short"]
                subscriberPlan = info["subscriberPlan"]
                startZoneId = info["startZoneId"]
                endZoneId = info["endZoneId"]
                cargoCapacity = info["cargoCapacity"]
                impulse = info["impulse"]
                salesManWorkingTime = info["salesManWorkingTime"]
                notes = info["notes"]
            end
            -- parts count should be 12
            if partsCount == 11 then
                ngx.log(ngx.ERR, "OK:")
                chunks[4] = chunks[4]..";"
            end
            if speedLimit ~= nil then
                chunks[4] = chunks[4]..speedLimit..";"
            else
                chunks[4] = chunks[4]..";"
            end
            if fuel ~= nil then
                chunks[4] = chunks[4]..fuel..";"
            else
                chunks[4] = chunks[4]..";"
            end
            if shortName ~= nil then
                chunks[4] = chunks[4]..shortName..";"
            else
                chunks[4] = chunks[4]..";"
            end
            if subscriberPlan ~= nil then
                chunks[4] = chunks[4]..subscriberPlan..";"
            else
                chunks[4] = chunks[4]..";"
            end
            if startZoneId ~= nil then
                chunks[4] = chunks[4]..startZoneId..";"
            else
                chunks[4] = chunks[4]..";"
            end
            if endZoneId ~= nil then
              chunks[4] = chunks[4]..endZoneId..";"
            else
              chunks[4] = chunks[4]..";"
            end
            if cargoCapacity ~= nil then
                chunks[4] = chunks[4]..cargoCapacity..";"
            else
                chunks[4] = chunks[4]..";"
            end
            if impulse ~= nil then
                chunks[4] = chunks[4]..impulse..";"
            else
                chunks[4] = chunks[4]..";"
            end
            if salesManWorkingTime ~= nil then
                chunks[4] = chunks[4]..salesManWorkingTime..";"
            else
                chunks[4] = chunks[4]..";"
            end
            if notes ~= nil then
                chunks[4] = chunks[4]..notes..";"
            else
                chunks[4] = chunks[4]..";"
            end
            response = table.concat(chunks, "\n")
        end
    end
    if args and args["c"] == "8" then -- set speed limit
        local chunks = utils.gsplit(response);
        if #chunks >= 1 and chunks[1] == "2" then -- успешно сохранилось сервисом, значит можно и нам
            local deviceId = args["i"];
            local speedWarn = args["x"];
            local speedMax = args["z"];
            store.save_speed_limit(deviceId, speedWarn, speedMax);
        end
    end
    if args and args["c"] == "10" then -- set device name
        local chunks = utils.gsplit(response);
        if #chunks >= 1 and chunks[1] == "2" then -- успешно сохранилось сервисом, значит можно и нам
            local deviceId = args["i"];
            local short = args["short"];
            local notes = args["notes"];
            store.save_short_name(deviceId, short);
            store.save_notes(deviceId, notes);
        end
    end
    if args and args["c"] == "4" then -- get history data
        local chunks = utils.gsplit(response);
        if #chunks >= 3 and chunks[3] ~= "" then
            local deviceId = args["i"];
            local limits = store.get_device_info(deviceId)
            if limits~=nil then
                chunks[3] = chunks[3]..";"..limits["speed_warn"]..";"..limits["speed_limit"]..";"..limits["isFilter"]
                response = table.concat(chunks, "\n")
            else -- если нет у нас в базе - пробуем достать от /x.x и сохранить в базу на будущее
                local sett = ngx.location.capture('/x.x', {method = ngx.HTTP_POST, body ="c=7&i="..deviceId.."&s="..args["s"]})
                local parts = utils.gsplit(sett.body);
                if #parts >= 3 and parts[4] ~= "" and parts[4] ~= "0" then
                    local tokens = utils.gsplit(parts[4],';')
                    local speed = tonumber(tokens[10])
                    if speed > 0 then
                        store.save_speed_limit(deviceId, speed, speed+20)
                        chunks[3] = chunks[3]..";"..speed..";"..(speed+20)..";0"
                        response = table.concat(chunks, "\n")
                    end
                end
            end
        end
    end
    if args and args["c"] == "28" then -- get stops data
        local deviceId = args["i"];
        local limits = store.get_device_info(deviceId)
        if limits~=nil and limits["fuel"]~="" then
            response = response.."fuel;"..limits["fuel"]
        end
        if limits~=nil and limits["impulse"]~="" then
            response = response.."\nimpulse;"..limits["impulse"]
        end
    end
    if args and args["c"] == "3" then -- get multicar data
        local chunks = utils.gsplit(response)
        local ids = {}
        -- индекс первого устройства онлайн, чтобы если пользователь заблокирован - не повторять перебор
        local onlineChunkIndex = 0;
        for i=1,#chunks do
            local row = chunks[i]
            if row:len() > 4 then
                local rowParts = utils.gsplit(row, ";")
                local from = row:find(";")
                if from~= nil then
                    local id = rowParts[1]
                    ids[#ids+1] = id
                end
                if onlineChunkIndex == 0 and tonumber(rowParts[4]) > 0 then
                    onlineChunkIndex = i
                end
            end
        end
        local limits = store.get_bulk_speed_limit(ids)
        local delta = 0
        for i=1,#chunks do
            local row = chunks[i]
            local found = false
            if row:len() > 4 and #limits >= i+delta then
                local from = row:find(";")
                if from~= nil then
                    local id = row:sub(1, from-1)
                    if tostring(limits[i+delta]["id"]) == id then
                        local iconv = require(ngx.var.lua_mod_prefix.."iconv")
                        chunks[i] = chunks[i]..";"..limits[i+delta]["speed_limit"]..";"..iconv.Utf8ToAnsi(tostring(limits[i+delta]["short"]))
                        found = true;
                    end
                end
            end
            if not found then
                delta = delta - 1
            end
        end
        local login = store.get_login()
        if login and login~=ngx.null then
            local isBlocked = store.has_permission("beBlocked")
            -- заблокированные пользователи видят только одно авто онлайн
            if isBlocked and onlineChunkIndex ~= 0 then
                local onlineChunk = chunks[onlineChunkIndex]
                chunks = {}
                chunks[1] = "3"
                chunks[2] = ""
                chunks[3] = onlineChunk..";blocked"
            end
        end
        response = table.concat(chunks, "\n")
    end
end
if not processed then
    -- просто запрос при котором надо обновить сессию или логаутнуть, если сессии нет
    local login = store.get_login()
    if login and login~=ngx.null then
        store.update_session()
        local router = require(ngx.var.lua_mod_prefix.."router")
        local routed_response = router.process()
        if routed_response~=nil then
            response = routed_response
        end
    else
        utils.force_logout()
    end
    store.release()
end
ngx.say(response)
