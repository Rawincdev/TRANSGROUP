(function () {
  "use strict";

  angular
    .module('app')
    .component('main', {
      templateUrl: 'app/main/main.html',
      controller: MainCtrl,
      controllerAs: 'vm'
    })
  ;

  MainCtrl.$inject = ['$rootScope', '$cookies', '$localStorage', '$filter', '$state', '$translate', '$mdMedia', 'Session', 'CarService', 'MapOsmService', 'ChartService', 'PermissionService', 'BackendApi', 'APP_EVENTS'];

  function MainCtrl($rootScope, $cookies, $localStorage, $filter, $state, $translate, $mdMedia, Session, CarService, MapOsmService, ChartService, PermissionService, BackendApi, APP_EVENTS) {
    var self = this,
      perm = PermissionService.get()
    ;
    var FEEDBACK_LINK = 'https://drive.google.com/open?id=1SqoPsxzGAeHEUK96ZqIMDE4h7UIwh4a91G0TaAxOSNA';

    BackendApi.getProfile()
      .then(function (result) {
        result.session || (window.location = '/logout');
      });

    this.$onInit = function () {
      this.login = Session.user.loginName;
      this.langs = [
        {name: 'UA', code: 'ua'},
        {name: 'EN', code: 'en'},
        {name: 'RU', code: 'ru'}
      ];
      this.langs.name = $localStorage.lang || 'ua';
      this.deviceType = 'desktop';

      if ( (navigator.userAgent.match(/Android/i)
          || navigator.userAgent.match(/webOS/i)
          || navigator.userAgent.match(/iPhone/i)
          || navigator.userAgent.match(/iPad/i)
          || navigator.userAgent.match(/iPod/i)
          || navigator.userAgent.match(/BlackBerry/i)
          || navigator.userAgent.match(/Windows Phone/i)
        ) || $mdMedia('max-width: 720px'))
      {
        this.deviceType = 'mobile';
        this.hideMap = true;
      }
      this.toolbar = initToolbar();
      MapOsmService.init();

      $rootScope.$on(APP_EVENTS.ui.openMap, function () {
        this.hideMap = false;
      }.bind(this));
    };

    this.onSelectLang = function (item) {
      $cookies.put('lang', item.code);
      $localStorage.lang = item.code;
      this.langs.name = item.name;
      $translate.use(item.code);
      //location.reload();
    };

    function initToolbar() {
      var actions = [
          {
            link: 'settings',
            name: $filter('translate')('page.settings'),
            message: 'Action 1',
            icon: 'settings',
            completed: true,
            error: true,
            handler: function () {}
          }, {
            link: 'logout',
            name: $filter('translate')('global.logout'),
            message: 'Action 3',
            icon: 'arrow_back',
            completed: true,
            error: true,
            handler: function () {}
          }
        ],
        toolbar = {
          buttons: [{
            name: $filter('translate')('global.toggleSizeTracker'),
            icon: 'settings_ethernet',
            handler: function () {
              self.changeSize = !self.changeSize;
              self.hideMap = false;
              onResize();
            }
          },{
            name: $filter('translate')('global.toggleMap'),
            icon: 'map',
            handler: function () {
              self.hideMap = !self.hideMap;
              self.changeSize = false;
              self.hideMap || onResize();
            }
          }],
          menus: [{
            name: $filter('translate')('page.control'),
            icon: 'menu',
            width: '4',
            actions: actions
          }]
        };

      if (perm.schedules) {
        actions.unshift({
          link: 'schedule',
          name: $filter('translate')('page.schedules'),
          icon: 'near_me',
          handler: function () {
            CarService.showSchedulesDialog();
          }
        });
      }

       if (perm.logistics) {
        var logisticsBtnOld = {
          className: 'btn-action',
          link: 'logistics',
          name: $filter('translate')('page.logistics'),
          icon: 'directions_car',
          handler: function () {
            $state.go('logistics.routes');
          }
        };
        actions.unshift(logisticsBtnOld);
        toolbar.buttons.push(logisticsBtnOld);
      }

      if (perm.cardBalanceSummary) {
        var cardBalanceBtn = {
          className: 'btn-action',
          link: 'cardBalance',
          name: $filter('translate')('page.cardBalance'),
          icon: 'attach_money',
          handler: function () {
            CarService.showCardBalanceDialog();
          }
        };
        actions.unshift(cardBalanceBtn);
        toolbar.buttons.push(cardBalanceBtn);
      }

      if (perm.reports) {
        var reportBtn = {
          className: 'btn-action',
          link: 'report',
          name: $filter('translate')('page.reports'),
          icon: 'assessment',
          handler: function () {
            CarService.showReportDialog();
          }
        };
        actions.unshift(reportBtn);
        toolbar.buttons.push(reportBtn);
      }

      toolbar.buttons.push({
        className: 'btn-action',
        name: $filter('translate')('global.feedback'),
        icon: 'feedback',
        handler: function () {
          var win = window.open(FEEDBACK_LINK, '_blank');
          win.focus();
        }
      });

      return toolbar;
    }

    function onResize () {
      setTimeout(function () {
        MapOsmService.initMapSize();
        ChartService.resize();
      }, 300);
    }

  }

})();
