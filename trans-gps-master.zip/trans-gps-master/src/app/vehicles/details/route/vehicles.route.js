(function () {
  "use strict";

  angular
    .module('app.vehicles')
    .component('vehiclesRoute', {
      bindings: {
        $transition$: '<',
        route: '<',
        history: '<',
        routeExtended: '<',
        isMultiAccaunt: '<'
      },
      templateUrl: 'app/vehicles/details/route/vehicles.route.html',
      controller: VehiclesRouteCtrl,
      controllerAs: 'vm'
    });

  VehiclesRouteCtrl.$inject = ['$scope', '$stateParams', '$log', '$localStorage', 'Session', 'APP_EVENTS', 'PeriodFilters', 'BackendApi', 'ResponseParser', 'MapOsmService', 'CarService', 'Utils'];

  function VehiclesRouteCtrl($scope, $stateParams, $log, $localStorage, Session, APP_EVENTS, PeriodFilters, BackendApi, ResponseParser, MapOsmService, CarService, Utils) {
    var self = this,
      titleFormat = '{time}, {speed}км/ч, {stopTime}{voltage}B'
    ;
    $scope.$root.app.title = 'page.route';
    this.tmp = {
      id: $stateParams.id,
      exports: ['routeXls', 'schedule', 'routeGPX', /*'fuelXls',*/ 'fuelPrint']
    };
    this.showPolilines = true;
    this.colorsFromStops = [];
    this.oneDayMarkers = '';
    this.polilinesWeight = 6;
    this.globalColors = Utils.getColors();
    this.extendedFilter = {};
    this.activeGeoZoneId = null;
    this.geoZoneHoldTime = null;

    self.$onInit = function () {
      self.addrType = Session.addressType;
      self.filter = PeriodFilters.getFilter('route');
      self.extendedFilter = {
        to: new Date(self.filter.to),
        from: new Date(self.filter.from)
      };
      self.carInfoControl = {};
      $scope.$emit(APP_EVENTS.ui.tabSelected, 'route');
      self.polilinesWeight = _.has($localStorage, 'routePolilinesWeight') ? $localStorage.routePolilinesWeight : 6;
      self.showPolilines = _.has($localStorage, 'showRoutePolilines') ? $localStorage.showRoutePolilines : true;
      detectStationaryCar();
      MapOsmService.clear();
      this.onChangeAddress();
      if (self.history.points && self.history.points.length) {
        self.history.points = CarService.detectParking(self.history.points, self.route.stops);
        MapOsmService.drawMarkersSet(self.history.points, titleFormat, true);
        self.showPolilines && self.getPolilinesToRoute();
      }

      const isControlPermissionSet = JSON.parse(sessionStorage.getItem('isControlPermissionSet'));

      self.hasControlPermission = (typeof isControlPermissionSet === 'boolean') ?
        isControlPermissionSet :
        Session.user.permissions.indexOf('geo-visits') !== -1;
    };

    this.$onDestroy = function () {
      MapOsmService.clearPolilinesGroup();
      MapOsmService.clearPolilines();
      MapOsmService.clearStartFinishMarkers();
    };

    // $log.log('Initial filter', self.filter);
    // $log.log('> route', self.route);
    // $log.log('> history', self.history);

    self.updateFilter = function (property) {
      if (property === 'dateTo') {
        self.extendedFilter.to = moment(self.filter.to).endOf("day").startOf("second").toDate();
        self.filter.to = self.extendedFilter.to;
        return;
      }
      if (property === 'timeTo') {
        self.extendedFilter.to = self.filter.to;
        return;
      }
      self.extendedFilter.to = moment(self.filter.to).endOf("day").startOf("second").toDate();
      self.extendedFilter[property] = self.filter[property];
    };

    /**
     * @description
     * Apply filter and get results from server.
     */
    self.applyFilter = function (noRenderChart) {
      delete $localStorage.sensorChunkParts;
      bindLoader(function () {
        MapOsmService.clearPolilinesGroup();
        MapOsmService.clearPolilines();
        return BackendApi.getStops(self.tmp.id, self.extendedFilter)
          .then(function (result) {
            self.route = result;
            detectStationaryCar();
            self.onChangeAddress();
            noRenderChart || self.onEmitFuelChart();
            self.onEmitCarInfo();
            // $log.log('> prepared route', self.list);
          });
      });

      BackendApi.getHistory(this.tmp.id, self.extendedFilter)
        .then(function (result) {
          // $log.log('> history', result);
          self.history = result;
          return BackendApi.getStopsExtended(self.tmp.id, self.extendedFilter);
        }).then(function (result) {
          self.routeExtended = result;
          MapOsmService.clear();
          if (result.points && result.points.length) {
            MapOsmService.drawMarkersSet(self.history.points, titleFormat, true);
            self.history.points = CarService.detectParking(self.history.points, self.route.stops);
            self.showPolilines && self.getPolilinesToRoute();
          }
        });
    };

    this.getPolylines = function (fromDate) {
      var dayRoute = [];
      _.each(self.routeExtended.points, function (item, i) {
        var date = moment(item.timestamp * 1000).format('DD.MM.YYYY');
        date === fromDate && dayRoute.push(item);
      })

      return self.getPolylinePoints(dayRoute);
    }

    this.onSetPolilineWeight = function (num) {
      self.polilinesWeight += num;
      $localStorage.routePolilinesWeight = self.polilinesWeight;
    }

    this.onTogglePolilinesToRoute = function () {
      MapOsmService.clearPolilinesGroup();
      self.showPolilines = !self.showPolilines;
      $localStorage.showRoutePolilines = self.showPolilines;
      self.showPolilines && self.getPolilinesToRoute();
    }

    this.onToggleOneDayRoute = function (item, color) {
      MapOsmService.clear();
      MapOsmService.clearPolilines();
      if (self.oneDayMarkers === item.fromDate) {
        self.oneDayMarkers = '';
        MapOsmService.drawMarkersSet(self.history.points, titleFormat, true);
        self.onDrawPolilinesGroup(false);

        $scope.$emit(APP_EVENTS.car.fuelChart, {
          zoomOptions: {
            from: undefined,
            to: undefined
          }
        });
      } else {
        self.oneDayMarkers = item.fromDate;
        MapOsmService.drawMarkersSet(self.getRoutePoints(item.fromDate), titleFormat, true);
        MapOsmService.drawPolilines(self.getPolylines(item.fromDate), color, self.polilinesWeight);

        $scope.$emit(APP_EVENTS.car.fuelChart, {
          zoomOptions: {
            from: +moment(item.fromDate, 'DD.MM.YYYY').startOf('day'),
            to: +moment(item.fromDate, 'DD.MM.YYYY').endOf('day')
          }
        });
      }
    }

    this.getRoutePoints = function (fromDate) {
      var dayRoute = [];
      _.each(self.history.points, function (item) {
        var date = moment.unix(item.timestamp).format('DD.MM.YYYY');
        if(date === fromDate) {
          dayRoute.push(item);
        }
      })

      return dayRoute;
    }

    this.getPolilinesToRoute = function () {
      self.colorsFromStops = [];
      MapOsmService.clearPolilinesGroup();
      self.onDrawPolilinesGroup(true);
    }

    this.onDrawPolilinesGroup = function (colorBox) {
      var colorIndex = colorIndexGenerator();
      var date = self.list.stops[0].fromDate,
        color = self.getColor(colorIndex);
      _.each(self.list.stops, function (item, i) {
        var points = self.getRoutePointsFromRange(item.onWayRange);

        if (date !== item.fromDate) {
          date = item.fromDate;
          color = self.getColor(colorIndex);
        }

        colorBox && self.colorsFromStops.push(color);
        MapOsmService.drawPolilinesGroup(self.getPolylinePoints(points), color, self.polilinesWeight);
      });
    }

    this.getRoutePointsFromRange = function (range) {
      return _.filter(self.routeExtended.points, function (point) {
        var timestamp = +point.timestamp * 1000;

        return (timestamp >= range.from) && (timestamp <= range.to);
      });
    }

    this.getColor = function (colorIndex) {
      var index = colorIndex.next().value;
      return this.globalColors[index] || Utils.getRandomeColor();
    }

    this.getPolylinePoints = function (stops) {
      var polylines = [];

      _.each(stops, function (stop) {
       var hasCoords = stop.latitude && stop.longitude;
        hasCoords && polylines.push([stop.latitude, stop.longitude]);
      });

      return polylines;
    }

    // Change color to opposite
    this.getReverseColor = function (color) {
      var hex = color.substring(1);
      return '#' + (Number('0x1' + hex) ^ 0xFFFFFF).toString(16).substr(1).toUpperCase()
    }

    this.replacePoints = function(newPoints, onWayRange) {
      var firstIndex, lastIndex;

      _.each(self.history.points, function(point, i) {
        if (+point.timestamp * 1000 <= onWayRange.from) {
          firstIndex = i;
        }

        if (+point.timestamp * 1000 <= onWayRange.to) {
          lastIndex = i;
        }
      })

      self.history.points.splice(firstIndex, lastIndex, newPoints);
    }

    this.showOnWayRange = function (item, index) {
      $log.log('onWayRange', item.onWayRange);
      if (activateItem(item)) {
        bindLoader(function () {
          return BackendApi.getHistory(self.tmp.id, item.onWayRange)
            .then(function (result) {
              MapOsmService.clear();
              if (result.points && result.points.length) {
                self.history.points = CarService.detectParking(self.history.points, self.route.stops);
                self.replacePoints(result.points, item.onWayRange)
                MapOsmService.drawMarkersSet(result.points, titleFormat, true);
                var points = self.getRoutePointsFromRange(item.onWayRange);
                self.showPolilines && self.getPolilinesToRoute();
                MapOsmService.drawPolilines(
                  self.getPolylinePoints(points),
                  self.getReverseColor(self.colorsFromStops[index]),
                  self.polilinesWeight
                );
              }
            });
        });
        self.onEmitFuelChart({filter: item.onWayRange, route: {
          stops: self.route.stops,
          summary: {
            fuelSettings: self.route.summary.fuelSettings,
            distanceKm: item.distance,
            maxSpeedKmpH: item.maxSpeed,
            engine: item.engine
          }
        }});
        self.onEmitCarInfo(item.onWayRange);
      } else {
        this.applyFilter(true);
        self.onEmitFuelChart();
      }
    };

    this.showOnStopRange = function (item) {
      if (activateItem(item)) {
        self.onEmitFuelChart({
          filter: {from: +(item.timestampFrom+'000'), to: +(item.timestampTo+'000')},
          route: {
            stops: self.route.stops,
            summary: {
              fuelSettings: self.route.summary.fuelSettings,
              distanceKm: item.distance,
              maxSpeedKmpH: item.maxSpeed,
              engine: item.engine
            }
          }
        });
        MapOsmService.clear();
        MapOsmService.showStop(item.latitude, item.longitude);
        //self.onEmitCarInfo({from: +(item.timestampFrom+'000'), to: +(item.timestampTo+'000')});
      } else {
        this.applyFilter(true);
        self.onEmitFuelChart();
      }
    };

    this.showStop = function (item) {
      if ('2' == item.status) {
        if (activateItem(item)) {
          MapOsmService.clear();
          MapOsmService.showStop(item.latitude, item.longitude);
        } else {
          this.applyFilter(true);
        }
      }
    };

    this.stripSeconds = function (time) {
      return time.slice(0, -3);
    };

    this.stripYear = function (time) {
      return time.slice(0, -5);
    };

    this.onToggleMove = function () {
      this.isToggleMove = !this.isToggleMove;
      this.onChangeAddress();
      self.showPolilines && self.getPolilinesToRoute();
    };

    this.onEmitFuelChart = function (options) {
      options = options || {};
      $scope.$emit(APP_EVENTS.car.fuelChart, _.extend({
        id: self.tmp.id,
        filter: self.extendedFilter,
        route: self.route,
        showDay: true
      }, options));
    };

    this.onEmitCarInfo = function (filter) {
      if (this.carInfoControl.updateCarInfo) {
        this.carInfoControl.updateCarInfo(filter);
      }
    }

    this.onToggleChart = function (isShow) {
      isShow && delete $localStorage.sensorChunkParts;
      this.onEmitFuelChart({show: isShow});
    };

    this.onChangeAddress = function (type) {
      this.list = ResponseParser.parseSingleDeviceRoute(this.route, this.isToggleMove, type || this.addrType);
    };

    this.onSetFilter = function (type) {
      this.extendedFilter.to = moment(this.extendedFilter.to).endOf("day").toDate();
      var filter = CarService.setFormFilter(this.extendedFilter, type);
      this.extendedFilter.from = filter.from;
      this.extendedFilter.to = filter.to;
      this.filter.from = filter.from;
      this.filter.to = filter.to;
      this.applyFilter();
    };

    this.getInfo = function (item) {
      return ($localStorage.combineFuel && $localStorage.combineFuel[self.tmp.id]) ? item.combinedFuelTankInfo : item.info;
    };

    this.filterByGeo = function (geo) {
      this.activeGeoZoneId = this.activeGeoZoneId === geo.id ? null : geo.id;

      const result = moment.duration();

      this.list.stops.filter(this.isItemVisible).forEach(function (item) {
        result.add(moment.duration(item.stopTime));
      });
      this.geoZoneHoldTime = result.hours() + ':' + result.minutes();
    };

    this.isItemVisible = function (item) {
      if (!self.activeGeoZoneId) {
        return true;
      }

      return item.geo && item.geo.id === self.activeGeoZoneId;
    };

    function* colorIndexGenerator () {
      var index = 0;

      while (index < self.globalColors.length)
        yield index++;
    }

    function activateItem (item) {
      if (item != self.tmp.item) {
        //previous item
        if (self.tmp.item) {
          self.tmp.item.isActive = false;
        }

        item.isActive = true;
        self.tmp.item = item;
      } else {
        item.isActive = false;
        self.tmp.item = null;
      }
      return item.isActive;
    }

    function detectStationaryCar () {
      if (self.route.summary && self.route.summary && self.route.summary.fuelSettings && !!self.route.summary.impulse) {
        $scope.$emit(APP_EVENTS.car.fuelBtn, {show: true});
      }
    }

    function bindLoader(func) {
      self.showLoader = true;
      func()
        .finally(function () {
          self.showLoader = false;
        });
    }

  }
})();
