(function () {
  "use strict";

  angular
    .module('app.vehicles')
    .component('vehiclesStops', {
      bindings: {
        route: '<',
        history: '<',
        routeExtended: '<',
        isMultiAccaunt: '<'
      },
      templateUrl: 'app/vehicles/details/stops/vehicles.stops.html',
      controller: VehiclesStopsCtrl,
      controllerAs: 'vm'
    });

  VehiclesStopsCtrl.$inject = ['$scope', '$stateParams', '$log', '$localStorage', 'Session', 'APP_EVENTS', 'PeriodFilters', 'BackendApi', 'ResponseParser', 'MapOsmService', 'CarService', '$mdToast', '$filter', 'Utils'];

  function VehiclesStopsCtrl($scope, $stateParams, $log, $localStorage, Session, APP_EVENTS, PeriodFilters, BackendApi, ResponseParser, MapOsmService, CarService, $mdToast, $filter, Utils) {
    var self = this,
      titleFormat = '{time}, {speed}км/ч, {stopTime}{voltage}B'
    ;
    $scope.$root.app.title = 'page.stops';
    this.tmp = {
      id: $stateParams.id,
      exports: ['stopsXls', 'schedule', 'stopsGPX', /*'fuelXls',*/ 'fuelPrint']
    };
    this.showPolilines = true;
    this.colorsFromStops = [];
    this.polilinesWeight = 6;
    this.globalColors = Utils.getColors();

    this.$onInit = function () {
      this.addrType = Session.addressType;
      this.filter = PeriodFilters.getFilter('stops');
      this.intervals = CarService.getIntervals('string');
      this.showActions = false;
      this.editingStopIndex = null;
      this.carInfoControl = {};
      this.activeGeoZoneId = null;
      this.geoZoneHoldTime = null;
      self.polilinesWeight = _.has($localStorage, 'stopsPolilinesWeight') ? $localStorage.stopsPolilinesWeight : 6;
      self.showPolilines = _.has($localStorage, 'showStopsPolilines') ? $localStorage.showStopsPolilines : true;
      $scope.$emit(APP_EVENTS.ui.tabSelected, 'stops');
      detectStationaryCar();
      MapOsmService.clear();
      this.onChangeAddress();
      if (this.history.points && this.history.points.length) {
        self.history.points = CarService.detectParking(self.history.points, self.route.stops);
        MapOsmService.drawMarkersSet(this.history.points, titleFormat, true);
        self.showPolilines && self.getPolilinesToOneDay();
      }

      const isControlPermissionSet = JSON.parse(sessionStorage.getItem('isControlPermissionSet'));

      self.hasControlPermission = (typeof isControlPermissionSet === 'boolean') ?
        isControlPermissionSet :
        Session.user.permissions.indexOf('geo-visits') !== -1;
    };

    this.$onDestroy = function () {
      this.clearStopActions(false);
      MapOsmService.clearPolilinesGroup();
      MapOsmService.clearPolilines();
      MapOsmService.clearStartFinishMarkers();
    };

    self.applyFilter = function (noRenderChart) {
      var filter = self.filter;
      delete $localStorage.sensorChunkParts;
      if (filter.from.toDateString() != filter.to.toDateString()) {
        filter.to.setFullYear(filter.from.getFullYear());
        filter.to.setMonth(filter.from.getMonth());
        filter.to.setDate(filter.from.getDate());
      }
      bindLoader(function () {
        MapOsmService.clearPolilinesGroup();
        MapOsmService.clearPolilines();
        return BackendApi.getStops(self.tmp.id, self.filter)
          .then(function (result) {
            self.route = result;
            detectStationaryCar();
            self.onChangeAddress();
            noRenderChart || self.onEmitFuelChart();
            self.onEmitCarInfo();
          });
      });

      BackendApi.getHistory(this.tmp.id, self.filter)
        .then(function (result) {
          // $log.log('> history', result);
          self.history = result;
          return BackendApi.getStopsExtended(self.tmp.id, self.filter);
        }).then(function (result) {
          self.routeExtended = result;
          MapOsmService.clear();
          if (result.points && result.points.length) {
            MapOsmService.drawMarkersSet(self.history.points, titleFormat, true);
            self.history.points = CarService.detectParking(self.history.points, self.route.stops);
            self.showPolilines && self.getPolilinesToOneDay();
          }
        });
    };

    this.getFuelUsage = function () {
      if (self.list.summary.tc) {
        self.fuelUsage = self.list.summary.totalFuelUsage;
      } else {
        self.fuelUsage = CarService.getFuelListForPrint(self.route, {}).summary.usage;
      }
    };

    this.onSetPolilineWeight = function (num) {
      self.polilinesWeight += num;
      $localStorage.stopsPolilinesWeight = self.polilinesWeight;
    }

    this.onTogglePolilinesToOneDay = function () {
      MapOsmService.clearPolilinesGroup();
      self.showPolilines = !self.showPolilines;
      $localStorage.showStopsPolilines = self.showPolilines;
      self.showPolilines && self.getPolilinesToOneDay();
    }

    this.getPolilinesToOneDay = function () {
      self.colorsFromStops = [];
      MapOsmService.clearPolilinesGroup();
      self.onDrawPolilinesGroup();
    }

    this.onDrawPolilinesGroup = function () {
      var colorIndex = colorIndexGenerator();
      _.each(self.list.stops, function (item, i) {
        var points = self.getRoutePointsFromRange(item.onWayRange);
        var color = self.hasOnWayTime(item.onWay) ? self.getColor(colorIndex) : 'transparent';
        self.colorsFromStops.push(color);
        MapOsmService.drawPolilinesGroup(self.getPolylinePoints(points), color, self.polilinesWeight);
      });
    }

    this.getRoutePointsFromRange = function (range) {
      return _.filter(self.routeExtended.points, function (point) {
        var timestamp = +point.timestamp * 1000;

        return (timestamp >= range.from) && (timestamp <= range.to);
      });
    }

    this.getColor = function (colorIndex) {
      var index = colorIndex.next().value;
      return this.globalColors[index] || Utils.getRandomeColor();
    }

    this.hasOnWayTime = function (onWay) {
      if(!onWay) return false;

      var onWayTime = moment(onWay, 'h:mm');
      var hasHour = !!onWayTime.get('hour');
      var hasMinute = !!onWayTime.get('minute');

      return hasHour || hasMinute;
    }

    this.getPolylinePoints = function (stops) {
      var polylines = [];

      _.each(stops, function (stop) {
        var hasCoords = stop.latitude && stop.longitude;

        hasCoords && polylines.push([stop.latitude, stop.longitude]);
      });

      return polylines;
    }

    this.replacePoints = function(newPoints, onWayRange) {
      var firstIndex, lastIndex;

      _.each(self.history.points, function(point, i) {
        if (+point.timestamp * 1000 <= onWayRange.from) {
          firstIndex = i;
        }

        if (+point.timestamp * 1000 <= onWayRange.to) {
          lastIndex = i;
        }
      })

      self.history.points.splice(firstIndex, lastIndex, newPoints);
    }

    this.showOnWayRange = function (item, index) {
      $log.log('onWayRange', item.onWayRange);

      if (activateItem(item)) {
        bindLoader(function () {
          return BackendApi.getHistory(self.tmp.id, item.onWayRange)
            .then(function (result) {
              MapOsmService.clear();
              if (result.points && result.points.length) {
                self.history.points = CarService.detectParking(self.history.points, self.route.stops);
                self.replacePoints(result.points, item.onWayRange);
                MapOsmService.drawMarkersSet(result.points, titleFormat, true);
                var points = self.getRoutePointsFromRange(item.onWayRange);
                self.showPolilines && self.getPolilinesToOneDay();
                MapOsmService.drawPolilines(self.getPolylinePoints(points), self.colorsFromStops[index], self.polilinesWeight);
              }
            });
        });
        self.onEmitFuelChart({filter: item.onWayRange, route: {
          stops: self.route.stops,
          summary: {
            fuelSettings: self.route.summary.fuelSettings,
            distanceKm: item.distance,
            maxSpeedKmpH: item.maxSpeed,
            engine: item.engine
          }
        }});
        self.onEmitCarInfo(item.onWayRange);
      } else {
        this.applyFilter(true);
        self.onEmitFuelChart();
      }
    };

    this.stripSeconds = function (time) {
      return time.slice(0, -3);
    };

    this.showOnStopRange = function (item) {
      if (activateItem(item)) {
        self.onEmitFuelChart({
          filter: {from: +(item.timestampFrom+'000'), to: +(item.timestampTo+'000')},
          route: {
            stops: self.route.stops,
            summary: {
              fuelSettings: self.route.summary.fuelSettings,
              distanceKm: item.distance,
              maxSpeedKmpH: item.maxSpeed,
              engine: item.engine
            }
          }
        });
        MapOsmService.clear();
        MapOsmService.showStop(item.latitude, item.longitude);
        //self.onEmitCarInfo({from: +(item.timestampFrom+'000'), to: +(item.timestampTo+'000')});
      } else {
        this.applyFilter(true);
        self.onEmitFuelChart();
      }
    };

    this.showStop = function (item) {
      if ('2' == item.status) {
        if (activateItem(item)) {
          MapOsmService.clear();
          MapOsmService.showStop(item.latitude, item.longitude);
          MapOsmService.goToPlace([item.latitude, item.longitude], 16);
        } else {
          this.applyFilter(true);
        }
      }
    };

    this.onToggleMove = function () {
      this.isToggleMove = !this.isToggleMove;
      this.onChangeAddress();
      self.showPolilines && self.getPolilinesToOneDay();
    };

    this.onEmitFuelChart = function (options) {
      options = options || {};
      $scope.$emit(APP_EVENTS.car.fuelChart, _.extend({
        id: self.tmp.id,
        filter: self.filter,
        route: self.route
      }, options));
    };

    this.onEmitCarInfo = function (filter) {
      if (this.carInfoControl.updateCarInfo) {
        this.carInfoControl.updateCarInfo(filter);
      }
    }

    this.onToggleChart = function (isShow) {
      isShow && delete $localStorage.sensorChunkParts;
      this.onEmitFuelChart({show: isShow});
    };

    this.onChangeAddress = function (type) {
      var list = ResponseParser.parseSingleDeviceRoute(this.route, this.isToggleMove, type || this.addrType);
      this.list = {summary: list.summary, stops: self.parseOfStopsTime(list.stops)};
      self.getFuelUsage();
    };

    this.parseOfStopsTime = function (list) {
      var parsedStopList = [];

      _.reduce(list, function (memo, next, index) {
        var cloneMemo = _.clone(memo);

        if (memo.status === '4' && next.status === '4') {
          if (memo.timestampFrom === self.getPreviouseTimestamp(parsedStopList)) {
            return next;
          }

          cloneMemo.timestampTo = next.timestampTo;
          cloneMemo.toTime = next.toTime;
        }

        parsedStopList.push(cloneMemo);
        list.length - 1 === index && parsedStopList.push(next);

        return next;
      });

      if (list.length === 1) {
        parsedStopList.push(list[0]);
      }

      return this.filterStops(parsedStopList);
    };

    this.filterStops = function (stops) {
      return _.filter(stops, function (item) {
        if ((item.timestampFrom === item.timestampTo) && item.status === '4') {
          return false;
        }

        return true;
      })
    }

    this.getPreviouseTimestamp = function (stops) {
      return stops.length ? stops[stops.length - 1].timestampTo : false;
    };

    this.getInfo = function (item) {
      if (item.status === '4') {
        var stopTime = moment.utc(moment.duration(item.toTime) - moment.duration(item.fromTime)).format('HH:mm:ss');
        return `${item.info.split(')')[0]}${stopTime})`;
      }

      return ($localStorage.combineFuel && $localStorage.combineFuel[self.tmp.id]) ? item.combinedFuelTankInfo : item.info;
    };

    this.onSetFilter = function (type) {
      var filter = CarService.setFormFilter(this.filter, type);
      this.filter.from = filter.from;
      this.filter.to = filter.to;
      this.applyFilter();
    };

    this.onSetFilterTime = function (time) {
      var filter = CarService.onSetFilterTime(time, this.filter.from);
      this.filter.from = filter.from;
      this.filter.to = filter.to;
      this.applyFilter();
    };

    this.onToggleActions = function () {
      self.showActions = !self.showActions;

      if (!self.showActions) {
        self.clearStopActions(true);
      }
    };

    this.saveStopAsGeozone = function (item) {
      if (item.zoneName && item.zoneColor) {
        var zone = {
          login: Session.user.loginName,
          name: item.zoneName,
          color: item.zoneColor,
          days: '',
        };

        MapOsmService.zoneSaved(zone).then(function () {
          var toast = $mdToast.simple().content($filter('translate')('global.savedSuccess')).position('bottom left');
          $mdToast.show(toast);
          self.clearStopActions(true);
        });
      }
    };

    this.editStopAsGeozone = function (item) {
      if (item.geo && item.geo.name && item.geo.color) {
        MapOsmService.zoneSaved(item.geo).then(function () {
          var toast = $mdToast.simple().content($filter('translate')('global.savedSuccess')).position('bottom left');
          $mdToast.show(toast);
          self.clearStopActions(true);
        });
      }
    };

    this.displayStopActions = function (index) {
      this.stopActionsIndex = index;
      var stop = this.list.stops[index];

      if (stop.geo) { // existing zone
        MapOsmService.startEditZone(stop.geo.id);
      } else { // new zone
        MapOsmService.startGeoEdit();
        MapOsmService.centerMapOnMarker(stop.latitude, stop.longitude);
      }
    };

    this.clearStopActions = function (uploadNewPoints) {
      this.stopActionsIndex = null;
      MapOsmService.cancelCurrentZone();
      MapOsmService.stopGeoEdit();
      if (uploadNewPoints) {
        this.applyFilter(true);
      }
    };

    this.onColorChanged = function (color) {
      MapOsmService.zoneColorChanged(color);
    };

    this.copyLocation = function (stop) {
      if (!stop.latitude || !stop.longitude) {
        return;
      }

      var latLon = (stop.latitude + ';' + stop.longitude);
      copyToClipboard(latLon);

      stop.isCopied = true;

      setTimeout(function(){
        stop.isCopied = false;
      }, 1000);

    };

    this.onDownloadXLSX = function () {
      function getCell(value, color, type) {
        if (color) {
          return {
            v: value || '',
            t: type || 's',
            s: { fill: { fgColor: { rgb: color } } }
          };
        }

        return value;
      }
      var DATE_FORMAT = 'YYYY.MM.DD';
      var GREEN_COLOR = 'B4F8C8';
      var rows = [];

      var list = ResponseParser.parseSingleDeviceRoute(this.route, true, this.addrType);

      var car = Session.user.cars.find(function (car) {
        return car.id === self.tmp.id;
      });

      var isFC = !!self.list.summary.fuelSettings;
      rows.push([$filter('translate')('reports.stops.car'), car ? car.name : '']);
      rows.push([$filter('translate')('reports.stops.date'), moment(self.filter.from).format(DATE_FORMAT)]);
      rows.push([$filter('translate')('reports.stops.expenseCalculation'), isFC ? 'ПК' : 'ДРП']);
      rows.push([$filter('translate')('reports.stops.mileage'), self.list.summary.distanceKm]);
      rows.push([$filter('translate')('reports.stops.maxSpeed'), self.list.summary.maxSpeedKmpH]);
      rows.push([$filter('translate')('reports.stops.fuelConsumption'), self.fuelUsage]);
      rows.push([$filter('translate')('reports.stops.avFuelConsumption'), self.list.summary.averageFuelUsage]);
      rows.push([$filter('translate')('reports.stops.engineTime'), $filter('formatDuration')(self.list.summary.engine)]);
      // header
      rows.push([
        getCell($filter('translate')('reports.stops.from'), GREEN_COLOR),
        getCell($filter('translate')('reports.stops.to'), GREEN_COLOR),
        getCell($filter('translate')('reports.stops.parkingTime'), GREEN_COLOR),
        getCell($filter('translate')('reports.stops.onWay'), GREEN_COLOR),
        getCell($filter('translate')('reports.stops.distance'), GREEN_COLOR),
        getCell($filter('translate')('reports.stops.maxSpeedShort'), GREEN_COLOR),
        getCell($filter('translate')('reports.stops.fuelConsumptionShort'), GREEN_COLOR),
        getCell($filter('translate')('reports.stops.address'), GREEN_COLOR)
      ]);

      // body
      var distance, maxSpeed, used, onWay;
      list.stops.forEach(function (item) {
        var isGreyRow = item.status === '0' || item.status === '1';
        var cellColor = isGreyRow ? 'ECEFF1' : undefined;

        if (item.status === '3') {
          distance = item.distance;
          maxSpeed = item.maxSpeed;
          used = item.used;
          onWay = item.onWay;
          return;
        }

        rows.push([
          getCell(item.fromTime, cellColor),
          getCell(item.toTime, cellColor),
          getCell(item.stopTime, cellColor),
          getCell(onWay, cellColor),
          getCell(distance, cellColor),
          getCell(maxSpeed, cellColor),
          getCell(used, cellColor),
          getCell(item.addressGoogle || item.addressYandex, cellColor)
        ]);

        if (item.status !== '3') {
          distance = undefined;
          maxSpeed = undefined;
          used = undefined;
          onWay = undefined;
        }
      });

      // footer
      rows.push([
        getCell('', GREEN_COLOR),
        getCell('', GREEN_COLOR),
        getCell(self.route.summary.totalHold, GREEN_COLOR),
        getCell(self.route.summary.totalWay, GREEN_COLOR),
        getCell(self.route.summary.distanceKm, GREEN_COLOR),
        getCell('', GREEN_COLOR),
        getCell(self.fuelUsage, GREEN_COLOR),
        getCell('', GREEN_COLOR)
      ]);

      var workbook = XLSX.utils.book_new();
      var worksheet = XLSX.utils.aoa_to_sheet(rows);

      workbook.SheetNames.push("stops");
      workbook.Sheets["stops"] = worksheet;

      XLSX.writeFile(workbook, 'stops.xlsx');
    };

    function* colorIndexGenerator () {
      var index = 0;

      while (index < self.globalColors.length)
        yield index++;
    }

    function copyToClipboard (str) {
      var el = document.createElement('textarea');  // Create a <textarea> element
      el.value = str;                                 // Set its value to the string that you want copied
      el.setAttribute('readonly', '');                // Make it readonly to be tamper-proof
      el.style.position = 'absolute';
      el.style.left = '-9999px';                      // Move outside the screen to make it invisible
      document.body.appendChild(el);                  // Append the <textarea> element to the HTML document
      var selected =
        document.getSelection().rangeCount > 0        // Check if there is any content selected previously
          ? document.getSelection().getRangeAt(0)     // Store selection if found
          : false;                                    // Mark as false to know no selection existed before
      el.select();                                    // Select the <textarea> content
      document.execCommand('copy');                   // Copy - only works as a result of a user action (e.g. click events)
      document.body.removeChild(el);                  // Remove the <textarea> element
      if (selected) {                                 // If a selection existed before copying
        document.getSelection().removeAllRanges();    // Unselect everything on the HTML document
        document.getSelection().addRange(selected);   // Restore the original selection
      }
    };

    this.filterByGeo = function (geo) {
      this.activeGeoZoneId = this.activeGeoZoneId === geo.id ? null : geo.id;

      const result = moment.duration();

      this.list.stops.filter(this.isItemVisible).forEach(function (item) {
        result.add(moment.duration(item.stopTime));
      });
      this.geoZoneHoldTime = result.hours() + ':' + result.minutes();
    };

    this.isItemVisible = function (item) {
      if (!self.activeGeoZoneId) {
        return true;
      }

      return item.geo && item.geo.id === self.activeGeoZoneId;
    };

    function activateItem (item) {
      if (item != self.tmp.item) {
        self.tmp.item && (self.tmp.item.isActive = false);
        item.isActive = true;
        self.tmp.item = item;
      } else {
        item.isActive = false;
        self.tmp.item = null;
      }
      return item.isActive;
    }

    function detectStationaryCar () {
      if (self.route.summary && self.route.summary && self.route.summary.fuelSettings && !!self.route.summary.impulse) {
        $scope.$emit(APP_EVENTS.car.fuelBtn, {show: true});
      }
    }

    function bindLoader(func) {
      self.showLoader = true;
      func()
        .finally(function () {
          self.showLoader = false;
        });
    }

  }
})();
