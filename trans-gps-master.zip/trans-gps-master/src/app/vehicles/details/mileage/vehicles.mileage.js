(function () {
  "use strict";

  angular
    .module('app.vehicles')
    .component('vehiclesMileage', {
      bindings: {
        data: '<'
      },
      templateUrl: 'app/vehicles/details/mileage/vehicles.mileage.html',
      controller: VehiclesMileageCtrl,
      controllerAs: 'vm'
    });

  VehiclesMileageCtrl.$inject = ['$scope', '$log', '$filter', 'Session', 'ResponseParser', 'BackendApi', 'PeriodFilters', 'MapOsmService', 'APP_EVENTS', 'CarService', 'FuelUsageService'];

  function VehiclesMileageCtrl($scope, $log, $filter, Session, ResponseParser, BackendApi, PeriodFilters, MapOsmService, APP_EVENTS, CarService, FuelUsageService) {
    var self = this,
      car = {id: $scope.$parent.$ctrl.carId}
    ;
    $scope.$root.app.title = 'page.mileage';
    this.tmp = {
      id: $scope.$parent.$ctrl.carId,
      exports: ['mileageXls', 'fuelCSV']
    };

    self.fuelReport = {
      data: []
    };

    self.$onInit = function () {
      $scope.$emit(APP_EVENTS.ui.tabSelected, 'mileage');
      MapOsmService.clear();
      self.addrType = Session.addressType;
      self.filter = PeriodFilters.getFilter('mileage');
      self.intervals = CarService.getIntervals('string');
      if (self.data.list.length) {
        bindLoader(function () {
          return self.getList().then(function () {
            self.getDaysFromIntervals();
          });
        });
      }
    };

    self.getReportFileName = function () {
      if (!self.data.list.length) {
        return $filter('translate')('car.noMileage');
      }

      var carName = _.find(Session.user.cars, function (car) {
        return car.id === self.tmp.id;
      }).name;
      var from = _.first(self.data.list).date;
      var to = _.last(self.data.list).date;

      return carName + '_distance_' + from + '_' + to;
    };

    self.getList = function () {
      return Promise.all(FuelUsageService.getPeriods(self.filter.from, self.filter.to, self.tmp.id)).then(function (response) {
        self.list = _.map(response, function (item) {
          return ResponseParser.parseSingleDeviceRoute(item, false, self.addrType);
        });
        self.fuels = FuelUsageService.getFuel(self.data.list, self.list);
        self.fuelReport.name = self.getReportFileName();
        self.totalFuelUsage = self.getTotal('totalFuelUsage');
        self.totalEngineWork = $filter('formatDuration')(self.getTotal('engine'));
        $scope.$apply();
      });
    };

    self.getFuelReportHeader = function () {
      return [
        $filter('translate')('global.date'),
        self.intervals.night,
        self.intervals.day,
        self.intervals.evening,
        '00:00-24:00',
        $filter('translate')('car.fuelConsumption'),
        $filter('translate')('car.averageFuelUsage'),
        $filter('translate')('car.engineWork'),
        $filter('translate')('car.maxMile')
      ];
    };
    self.getDaysFromIntervals = function () {
      self.totalDay = 0;
      self.totalEvening = 0;
      self.totalNight = 0;
      self.totalAllDay = 0;
      self.averageTotalFuelUsage = 0;
      self.fuelReport.data = [];
      self.fuelReport.data.push(self.getFuelReportHeader());

      _.each(self.data.list, function (item, index) {
        self.totalDay = (Number(self.totalDay) + Number(self.data.list[index].day)).toFixed(1);
        self.totalEvening = (Number(self.totalEvening) + Number(self.data.list[index].evening)).toFixed(1);
        self.totalNight = (Number(self.totalNight) + Number(self.data.list[index].night)).toFixed(1);
        self.totalAllDay = (Number(self.totalAllDay) + Number(self.data.list[index].total)).toFixed(1);
        var bodyInfo = [
          item.date,
          Number(self.data.list[index].night),
          Number(self.data.list[index].day),
          Number(self.data.list[index].evening),
          Number(self.data.list[index].total),
          Number(self.fuels[item.date].totalFuelUsage),
          Number(self.fuels[item.date].averageFuelUsage),
          $filter('formatDuration')(self.fuels[item.date].engine),
          item.maxSpeed
        ];
        self.fuelReport.data.push(bodyInfo);
        if (index === (self.data.list.length - 1)) {
          self.averageTotalFuelUsage = ((self.totalFuelUsage / self.totalAllDay) * 100).toFixed(1);
          var footerInfo = [
            $filter('translate')('car.total'),
            Number(self.totalNight),
            Number(self.totalDay),
            Number(self.totalEvening),
            Number(self.totalAllDay),
            Number(self.totalFuelUsage),
            Number(self.averageTotalFuelUsage),
            self.totalEngineWork,
            self.data.total.maxSpeed
          ];
          self.fuelReport.data.push(footerInfo);
          $scope.$apply();
        }
      });
    };

    self.getTotal = function (field) {
      var total = 0;
      _.each(self.fuels, function (item) {
        total += Number(item[field]);
      });

      return total.toFixed(1);
    };

    self.parseList = function (list) {
      return _.map(list, function (item) {
        return ResponseParser.parseSingleDeviceRoute(item, false, self.addrType);
      });
    };

    self.updateFilter = function (property) {
      $log.log(property, self.filter);
    };

    self.applyFilter = function () {
      self.filter.to = moment(self.filter.to).endOf("day").startOf("second").toDate();
      $log.log('applyFilter', self.filter);
      bindLoader(function () {
        return BackendApi.getMileage(car, self.filter)
          .then(function (result) {

            // remove day that out of the range
            if (result.list.length) {
              var lastDay = result.list.pop();
              if ((new Date(lastDay.timestamp * 1000)) > self.filter.to) {
                _.each(['night', 'day', 'evening', 'total', 'fuel'], function (prop) {
                  result.total[prop] = (Number(result.total[prop]) - Number(lastDay[prop])).toFixed(1);
                });
              } else {
                result.list.push(lastDay)
              }
            }

            self.data = result;
            // here
            return !!result.list.length;
          }).then(function (hasDataList) {
            if (hasDataList) {
              return self.getList();
            }
          }).then(function () {
            if (self.data.list.length) {
              self.getDaysFromIntervals();
            }
          });
      });
    };

    self.onSetFilter = function (type) {
      var filter = CarService.setFormFilter(this.filter, type);
      this.filter.from = filter.from;
      this.filter.to = filter.to;
      this.applyFilter();
    };

    function bindLoader(func) {
      self.showLoader = true;
      func()
        .finally(function () {
          self.showLoader = false;
        });
    }

  }
})();
