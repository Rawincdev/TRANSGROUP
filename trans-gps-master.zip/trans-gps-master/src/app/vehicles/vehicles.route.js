(function () {
  "use strict";

  angular
    .module('app.vehicles', [])
    .config(vehiclesRoutesConfig);

  /** @ngInject */
  function vehiclesRoutesConfig($stateProvider) {
    $stateProvider
      .state('vehicles', {
        parent: 'main',
        redirectTo: 'vehicles.all',
        component: 'vehicles',
        resolve: {},
      })
      .state('vehicles.all', {
        parent: 'vehicles',
        url: '/vehicles',
        component: 'vehiclesAll',
        /*resolve: {
          vehicles: ['BackendApi', function (BackendApi) {
            return BackendApi.getCarNow(0);
          }]
        }*/
      })
      .state('vehicles.details', {
        parent: 'vehicles',
        component: 'vehiclesDetails',
      })
      .state('vehicles.details.now', {
        parent: 'vehicles.details',
        url: '/vehicles/:id/now',
        resolve: {
          vehicles: [
            'BackendApi',
            '$stateParams',
            function (BackendApi, $stateParams) {
              return BackendApi.getCarNow($stateParams.id);
            },
          ],
        },
        views: {
          now: 'vehiclesNow',
        },
      })
      .state('vehicles.details.route', {
        parent: 'vehicles.details',
        url: '/vehicles/:id/route',
        resolve: {
          route: [
            'BackendApi',
            'PeriodFilters',
            '$stateParams',
            function (BackendApi, PeriodFilters, $stateParams) {
              return BackendApi.getStops(
                $stateParams.id,
                PeriodFilters.getFilter('route')
              );
            },
          ],
          routeExtended: ['BackendApi', 'PeriodFilters', '$stateParams', function (BackendApi, PeriodFilters, $stateParams) {
            return BackendApi.getStopsExtended($stateParams.id, PeriodFilters.getFilter('route'));
          }],
          history: [
            'BackendApi',
            'PeriodFilters',
            '$stateParams',
            function (BackendApi, PeriodFilters, $stateParams) {
              return BackendApi.getHistory(
                $stateParams.id,
                PeriodFilters.getFilter('route')
              );
            },
          ],
          isMultiAccaunt: ['Session', function (Session) {
            return Session.user.loginType === '0';
          }]
        },
        views: {
          route: 'vehiclesRoute',
        },
      })
      .state('vehicles.details.report', {
        parent: 'vehicles.details',
        url: '/vehicles/:id/report?from&to&ids',
        resolve: {
          data: [
            '$stateParams',
            'FuelReportService',
            function ($stateParams, FuelReportService) {
              var reportText = '';
              var params = {
                id: $stateParams.id,
                ids: $stateParams.ids ? $stateParams.ids.split(',') : [],
                from: $stateParams.from,
                to: $stateParams.to
              };

              if (params.ids.length) {
                // TODO: Generate report with multiple car id's
                FuelReportService.getFuelReportWithIds(params)
                // .then(function (reports) {
                //   reportText = reports.join();
                //   FuelReportService.createReportFile(reportText, params);
                // });
                // FuelReportService.createReportFile(reportText, params);
              } else {
                FuelReportService.getFuelReport($stateParams.id, params)
                .then(
                  function (text) {
                    reportText = text;
                    FuelReportService.createReportFile(reportText, params);
                  }
                );
              };
            },
          ],
        }
      })
      .state('vehicles.details.mileage', {
        parent: 'vehicles.details',
        url: '/vehicles/:id/mileage',
        resolve: {
          data: ['BackendApi', 'PeriodFilters', '$stateParams', function (BackendApi, PeriodFilters, $stateParams) {
            return BackendApi.getMileage({id: $stateParams.id}, PeriodFilters.getFilter('mileage'));
          }]
        },
        views: {
          mileage: 'vehiclesMileage'
        }
      })
      .state('vehicles.details.stops', {
        parent: 'vehicles.details',
        url: '/vehicles/:id/stops?date',
        resolve: {
          route: ['BackendApi', 'PeriodFilters', '$stateParams', function (BackendApi, PeriodFilters, $stateParams) {
            return BackendApi.getStops($stateParams.id, PeriodFilters.getFilter('stops'));
          }],
          routeExtended: ['BackendApi', 'PeriodFilters', '$stateParams', function (BackendApi, PeriodFilters, $stateParams) {
            return BackendApi.getStopsExtended($stateParams.id, PeriodFilters.getFilter('stops'));
          }],
          history: ['BackendApi', 'PeriodFilters', '$stateParams', function (BackendApi, PeriodFilters, $stateParams) {
            return BackendApi.getHistory($stateParams.id, PeriodFilters.getFilter('stops'));
          }],
          isMultiAccaunt: ['Session', function (Session) {
            return Session.user.loginType === '0';
          }]
        },
        views: {
          stops: 'vehiclesStops'
        }
      })
      .state('vehicles.details.settings', {
        parent: 'vehicles.details',
        url: '/vehicles/:id/settings',
        resolve: {
          settings: ['BackendApi', '$stateParams', function (BackendApi, $stateParams) {
            return BackendApi.getCarSettings({id: $stateParams.id});
          }],
          carSubscriberPlans: ['BackendApi', function (BackendApi) {
            return BackendApi.getCarsSubscriberPlans();
          }]
        },
        views: {
          settings: 'vehiclesSettings'
        }
      });
  }
})();
