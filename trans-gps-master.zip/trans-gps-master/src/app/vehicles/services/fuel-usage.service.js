(function () {
  'use strict';

  angular.module('app.vehicles').service('FuelUsageService', FuelUsageService);

  FuelUsageService.$inject = ['BackendApi', 'CarService'];

  function FuelUsageService(BackendApi, CarService) {
    var self = this;

    self.getPeriods = function (dateFrom, dateTo, id) {
      var requests = [];

      var start = moment(dateFrom);
      var end = moment(dateTo).endOf('day');
      var dayDuration = moment.duration(end.diff(start)).asDays();

      for (var i = 0; i < dayDuration; i++) {
        var from = moment(dateFrom).add(i, 'days').toDate();
        var to = moment(dateFrom)
          .add(i, 'days')
          .endOf('day')
          .startOf('second')
          .toDate();
        requests.push(BackendApi.getStops(id, { from: from, to: to }));
      }

      return requests;
    };

    self.getFuel = function (datalist, list) {
      var fuels = {};

      _.each(datalist, function (item) {
        fuels[item.date] = getFuelUsage(item, list);
      });

      return fuels;
    };

    function getFuelUsage(dataItem, list) {
      var fuel = {
        totalFuelUsage: '0.0',
        fuelStart: '0.0',
        fuelEnd: '0.0',
        merged: '0.0',
        refilled: '0.0',
        averageFuelUsage: '0.0',
        distanceKm: '0.0',
        maxSpeedKmpH: '0.0',
        date: dataItem.date,
        engine: '0.0'
      };

      _.each(list, function (listItem) {
        if (!listItem.stops.length) return;

        var stopsDate = moment(listItem.stops[0].timestampFrom * 1000).format(
          'YYYY.MM.DD'
        );

        if (stopsDate === dataItem.date) {
          var fuelForPrint = CarService.getFuelListForPrint(listItem, {}).list[0];

          if (
            _.has(listItem.summary, 'totalFuelUsage') &&
            +listItem.summary.totalFuelUsage !== 0
          ) {
            fuel.totalFuelUsage = listItem.summary.totalFuelUsage;
            fuel.averageFuelUsage = listItem.summary.averageFuelUsage;
            fuel.distanceKm = listItem.summary.distanceKm;
            fuel.maxSpeedKmpH = listItem.summary.maxSpeedKmpH;
            fuel.engine = listItem.summary.engine;
            fuel.fuelStart = fuelForPrint ? fuelForPrint.fuelStart : 0;
            fuel.fuelEnd = fuelForPrint ? fuelForPrint.fuelEnd : 0;
            fuel.merged = fuelForPrint ? fuelForPrint.merged : 0;
            fuel.refilled = fuelForPrint ? fuelForPrint.refilled : 0;

            return;
          }

          fuel.totalFuelUsage = _.has(dataItem, 'fuel') ? dataItem.fuel : '0.0';
        }
      });

      return fuel;
    }
  }
})();
