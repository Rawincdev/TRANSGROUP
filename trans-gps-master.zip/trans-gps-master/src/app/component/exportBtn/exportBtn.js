(function () {
  "use strict";

  angular
    .module('app')
    .component('exportBtn', {
      bindings: {
        id: '<',
        cars: '<',
        report: '<',
        filter: '<',
        btnsType: '<',
        fuels: '<',
        direction: '@',
        route: '<'
      },
      templateUrl: 'app/component/exportBtn/exportBtn.html',
      controller: ExportBtnCtrl,
      controllerAs: 'vm'
    });

  ExportBtnCtrl.$inject = ['$element', '$mdDialog', '$filter', 'Session', 'CarService', 'DateUtils'];

  function ExportBtnCtrl($element, $mdDialog, $filter, Session, CarService, DateUtils) {
    this.form = {};
    var self = this, car;
    var date = $filter('translate')('logistics.create-route.startDate');
    var fuelUsage = $filter('translate')('car.totalFuelUsage');
    var averageFuelUsage = $filter('translate')('car.fuelPrint.averageFuelUsage');
    var jsonFields = [date, fuelUsage, averageFuelUsage];
    var btns = [
      {
        btnType: "routeXls",
        title: "exportBtn.loadXLS",
        type: "stops",
        subtype: "route",
        format: "xls"
      },{
        btnType: "routeGPX",
        title: "GPX"
      },{
        btnType: "mileageXls",
        title: "exportBtn.loadXLS",
        type: "distance",
        format: "xls"
      },{
        btnType: "stopsXls",
        title: "exportBtn.loadXLS",
        type: "stops",
        subtype: "stops",
        format: "xls"
      },{
        btnType: "stopsGPX",
        title: "Tрек в GPX"
      },{
        btnType: "schedule",
        title: "exportBtn.saveAsRoute"
      },{
        btnType: "reportXls",
        title: "exportBtn.loadXLS",
        type: "report",
        subtype: "route",
        format: "xls"
      },{
        btnType: "fuelXls",
        title: "exportBtn.loadXLSFuel",
        type: "fuel",
        format: "xls"
      },{
        btnType: "fuelPrint",
        title: "exportBtn.printFuel",
        icon: "print"
      },{
        btnType: "fuelCSV",
        title: "exportBtn.loadFuelCSV",
        type: "fuel",
        format: "csv"
      }
    ];

    this.$onInit = function () {
      this.id && (car = _.findWhere(Session.user.cars, {id: this.id.toString()}) || {});
      this.btns = _.filter(btns, function (el) {
        return _.contains(self.btnsType, el.btnType);
      });
    };

    this.onSubmit = function (btn) {
      if ('schedule' == btn.btnType) {
        CarService.showSchedulesDialog();
      } else if ('fuelPrint' == btn.btnType) {
        onShowFuelPrintDialog();
      } else {
        var report = {}, formId = _.contains(['routeGPX', 'stopsGPX'], btn.btnType) ? ".export-form-gpx" : ".export-form";

        if (btn.btnType === 'fuelCSV') {
         var csvStr = jsonToCSV();
          downloadCSV(csvStr);
          return;
        }

        if (btn.btnType == 'reportXls') {
          _.extend(report, {
            id: _.map(this.cars, function (el) {
              return el.id;
            }).join(","),
            names: _.map(this.cars, function (el) {
              return el.name;
            }).join(";"),
            reportName: this.report,
            limits: DateUtils.joinAllDateForPeriod(this.filter)
          });
        }

        if (btn.btnType == 'mileageXls') {
          mileageToXls();
          return;
        }

        this.form = _.extend(btn, car, report, {
          from: moment(this.filter.from).unix(),
          to: moment(this.filter.to).startOf('minute').unix(),
          lang: Session.lang
        });

        setTimeout(function () {
          $element[0].querySelector(formId).submit();
        }, 100);
      }
    };

    function onShowFuelPrintDialog () {
      $mdDialog.show({
        controllerAs: 'vm',
        controller: FuelPrintDialogCtrl,
        templateUrl: 'app/component/exportBtn/car-fuel-print-dialog.html',
        fullscreen: true,
        locals: {
          resolveData: {filter: self.filter, car: car, stops: self.route.stops}
        }
      });
    }

    function jsonToCSV() {
     var csvStr = jsonFields.join(",") + "\n";

      _.each(self.fuels, function (element) {
       var date = element.date;
       var totalFuelUsage = element.totalFuelUsage;
       var averageFuelUsage = element.averageFuelUsage;

        csvStr += date + "," + totalFuelUsage + "," + averageFuelUsage + "\n";
      });

      return csvStr;
    }

    function downloadCSV(csvStr) {
      var hiddenElement = document.createElement("a");
      hiddenElement.href = "data:text/csv;charset=utf-8," + encodeURI(csvStr);
      hiddenElement.target = "_blank";
      hiddenElement.download = "fuels.csv";
      hiddenElement.click();
    }

    function mileageToXls() {
      var wb = XLSX.utils.book_new();
      wb.Props = {
        Title: 'Mileage Report',
        Subject: 'Mileage',
        Author: 'TransGPS',
        CreatedDate: new Date()
      };

      wb.SheetNames.push('Mileage Sheet');
      var wsData = _.sortBy(self.report.data, function (i) {
        return new Date(i[0]);
      });
      var ws = XLSX.utils.aoa_to_sheet(wsData);
      wb.Sheets['Mileage Sheet'] = ws;
      var wbout = XLSX.write(wb, {bookType: 'xls', type: 'binary'});

      saveAs(new Blob([s2ab(wbout)], {type: "application/octet-stream"}), self.report.name + '.xls');
    }

    function s2ab(s) {
      var buf = new ArrayBuffer(s.length);
      var view = new Uint8Array(buf);
      for (var i = 0; i < s.length; i++) {
        view[i] = s.charCodeAt(i) & 0xff;
      }
      return buf;
    }
  }

  FuelPrintDialogCtrl.$inject = ['$element', '$scope', '$filter', '$mdDialog', 'CarService', 'resolveData', 'BackendApi', '$stateParams'];

  function FuelPrintDialogCtrl($element, $scope, $filter, $mdDialog, CarService, resolveData, BackendApi, $stateParams) {
    var self = this, title;
    self.daysSummary = {};
    self.route = {};

    init();

    this.onCancel = function () {
      $mdDialog.cancel();
    };

    this.onDischargeToUsage = function () {
      _.extend(self.print, CarService.getFuelListForPrint(self.route, self.daysSummary, this.isDischargeToUsage));
    };

    this.getUsageWithDischarge = function (printItem) {
      return printItem.fuelStart + printItem.refilled - 0 - printItem.fuelEnd;
    };

    this.onPrintFuel = function () {
      setTimeout(function () {
        var printWindow = window.open('', title);
        printWindow.document.write($element[0].querySelector('.fuel-print-tpl').innerHTML);
        printWindow.document.title = [title, self.print.from, self.print.to].join(' - ');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
      }, 1000);
    };

    function init() {
      title = $filter('translate')('car.fuelPrint.title');
      var filters = []
      var from = moment(resolveData.filter.from);
      var to = moment(resolveData.filter.to).endOf('day');

      var fullDays = to.diff(from, 'days');


      for (var i = 0; i <= fullDays; i++) {
        var f, t;
        if (i === 0) {
          f = from;
        } else {
          f = from.clone().add(i, 'days').startOf('day')
        }

        if (i === fullDays) {
          t = to;
        } else {
          t = f.clone().endOf('day');
        }
        filters.push({from: f.toDate(), to: t.toDate()});
      }

      Promise.all(filters.map(function (filter) {
        return BackendApi.getStops($stateParams.id, filter).then(function (result) {
          self.daysSummary[moment(filter.from).format('DD.MM.YYYY')] = result.summary;
          return result;
        });
      })).then(function (data) {
        self.route.stops = _.flatten(_.map(data, function (item) {
          return item.stops;
        }));
        self.route.summary = data[0].summary
        self.print = _.extend({
          from: from.format('L HH:mm'),
          to: to.format('L HH:mm')
        }, CarService.getFuelListForPrint(self.route, self.daysSummary), resolveData.car);
        $scope.$apply();
      });
    }
  }

})();
