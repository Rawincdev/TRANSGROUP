(function () {
  "use strict";

  angular
    .module('app')
    .component('changeAddress', {
      bindings: {
        type: '=',
        onChange: '&',
        showCol: '<',
        showCombineFuelTanks: '<',
      },
      template: '' +
      '<md-radio-group ng-model="vm.type" class="change-address layout-row layout-align-center-center" ng-change="vm.onChangeType()">' +
        '<div class="car-thead-col" ng-if="vm.showCol">' +
          '<span class="car-link" ng-click="vm.onToggleCol(0)">ID</span>&nbsp;&nbsp;&nbsp;<span class="car-link" ng-click="vm.onToggleCol(1)">F</span>' +
        '</div>' +
        '<div class="car-thead-col" ng-if="vm.showCombineFuelTanks">' +
          '<span class="car-link" ng-click="vm.onCombineFuelTanks()">F{{vm.isCombinedFuelTanks ? "+" : "-"}}</span>' +
        '</div>' +
        '<div class="hide-sm hide-xs"><span translate="global.address">Адрес</span>:&nbsp;&nbsp;&nbsp;</div>' +
        '<md-radio-button ng-repeat="item in vm.addrs" value="{{item.code}}" class="md-primary">{{item.name}}</md-radio-button>' +
      '</md-radio-group>',
      controllerAs: 'vm',
      controller: ['$localStorage', 'Session', '$stateParams', function ChangeAddressCtrl($localStorage, Session, $stateParams) {
        var self = this,
          hideCol = {},
          tableHtml = document.querySelector('.table-car-all')
        ;
        this.addrs = [{
          name: 'Google',
          code: 'addressGoogle'
        }, {
          name: 'Yandex',
          code: 'addressYandex'
        }];
        this.type = this.type || Session.addressType;
        this.isCombinedFuelTanks = !!($localStorage.combineFuel && $localStorage.combineFuel[$stateParams.id]);

        this.onChangeType = function () {
          Session.addressType = this.type;
          _.isFunction(this.onChange) && this.onChange({type: this.type});
        };

        this.onToggleCol = function (pos) {
          if (hideCol.hasOwnProperty(pos)) {
            tableHtml.classList.remove('hide-col-' + pos);
            delete hideCol[pos];
          } else {
            tableHtml.classList.add('hide-col-' + pos);
            hideCol[pos] = true;
          }
          $localStorage.hideCol = hideCol;
        };

        this.showCol && _.each($localStorage.hideCol, function (val, key) {
          self.onToggleCol(key);
        });

        this.onCombineFuelTanks = function () {
          if (!$localStorage.combineFuel) {
            $localStorage.combineFuel = {};
          }
          if ($localStorage.combineFuel[$stateParams.id]) {
            delete $localStorage.combineFuel[$stateParams.id];
          } else {
            $localStorage.combineFuel[$stateParams.id] = true;
          }
          self.isCombinedFuelTanks = !!$localStorage.combineFuel[$stateParams.id];
        };
        
      }]
    });

})();
