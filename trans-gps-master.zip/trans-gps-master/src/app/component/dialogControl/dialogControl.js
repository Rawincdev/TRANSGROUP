(function () {
  "use strict";

  angular
    .module('app')
    .component('dialogControl', {
      templateUrl: 'app/component/dialogControl/dialogControl.html',
      controllerAs: 'vm',
      controller: function SaveBtnCtrl() {
        var container;

        this.$onInit = function () {
          container = document.querySelector('md-dialog');
        };

        this.onFullscreen = function () {
          this.isFullscreen = true;
          container.classList.add('dialog-fullscreen');
        };

        this.onFullscreenExit = function () {
          this.isFullscreen = false;
          container.classList.remove('dialog-fullscreen');
        };


      }
    });

})();
