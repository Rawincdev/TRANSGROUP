module.exports = {
  extends: [
    'angular'
  ],
  rules: {
    'angular/no-service-method': 0,
      'linebreak-style': 0,
      'one-var': 0
  }
}
