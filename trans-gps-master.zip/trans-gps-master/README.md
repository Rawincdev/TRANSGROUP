trans-gps-md
============

Для запуска приложения необходимо чтобы в системе были: 
1) nodejs (https://nodejs.org/uk/download/package-manager/)
2) bower (`npm install -g bower`)
3) gulp (`npm install -g gulp-cli`)

После этого необходимо в консоле выполнить следующие команды:
1) `npm install`
2) `bower install`
3) `gulp serve:dist`

Содержимое папки `dist` необходимо скопировать в `/var/www/...`

Для переноса сайта на orbita-gps.com. Необходимо скопировать идентичные файлы в идентичные директории:
- /index.html
- /styles
- /lua
- /scripts
- открыть /scripts/app-......js найти с помощью поиска найти текст "Trans-Gps" и заменить на "Orbita-Gps", тоже самое для "TransGps"
